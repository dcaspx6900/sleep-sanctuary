"use client";

export default function OrganicBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Primary blob */}
      <div
        className="absolute w-72 h-72 rounded-full animate-mf-pulse-organic"
        style={{
          background: "radial-gradient(circle, rgba(206,233,221,0.5) 0%, transparent 70%)",
          top: "-5%",
          right: "-15%",
        }}
      />
      {/* Secondary blob */}
      <div
        className="absolute w-64 h-64 rounded-full animate-mf-pulse-organic"
        style={{
          background: "radial-gradient(circle, rgba(200,230,255,0.35) 0%, transparent 70%)",
          bottom: "10%",
          left: "-20%",
          animationDelay: "4s",
        }}
      />
      {/* Tertiary blob */}
      <div
        className="absolute w-56 h-56 rounded-full animate-mf-pulse-organic"
        style={{
          background: "radial-gradient(circle, rgba(250,200,152,0.3) 0%, transparent 70%)",
          top: "40%",
          right: "-10%",
          animationDelay: "8s",
        }}
      />
    </div>
  );
}
