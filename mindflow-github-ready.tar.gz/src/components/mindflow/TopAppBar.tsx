"use client";

import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore, HIDE_TOPBAR_VIEWS } from "@/lib/store";

const PROFILE_IMAGE_URL =
  "https://lh3.googleusercontent.com/aida-public/AB6AXuBp0zEZaM2TPJydM9HNbwWIP77PDYUDsA_saMncJ8xbBooy-1MioMRPzjE3Ts63nOUNc474P7iTgi-3_AaHGCbVDNYzIprLut5Q4C7tNbXiC1HnKx3G-d88vJqjzi02W9iLCUXvo4pUtDabM-R4lxH1V9ZUrM0XOYNztVB7gnM_2p1-uW446TZsfIDHUJ4-QnpYv5S08A0NRGbprERMvZXZVQonn9uIOh-VSZ7yQ4JZ-tfpfjcR_htu_WaFPQAvU06OpK5thajQZoQ";

interface TopAppBarProps {
  showBack?: boolean;
  title?: string;
  rightAction?: React.ReactNode;
}

export default function TopAppBar({
  showBack,
  title,
  rightAction,
}: TopAppBarProps) {
  const { currentView, goBack, timeOfDay } = useAppStore();

  if (HIDE_TOPBAR_VIEWS.includes(currentView)) return null;

  const isHome = currentView === "home";
  const greeting =
    timeOfDay === "morning"
      ? "Good Morning"
      : timeOfDay === "afternoon"
        ? "Good Afternoon"
        : "Good Evening";

  return (
    <header className="sticky top-0 z-50 bg-mf-surface/80 dark:bg-[#0e0e0d]/80 backdrop-blur-xl px-5 pt-4 pb-3">
      <div className="flex items-center justify-between">
        {/* Left section */}
        <div className="flex items-center gap-3">
          {showBack && (
            <button
              onClick={goBack}
              className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-mf-surface-container-high dark:hover:bg-white/5 transition-colors"
              aria-label="Go back"
            >
              <MaterialIcon
                icon="arrow_back"
                className="text-mf-on-surface dark:text-stone-100"
              />
            </button>
          )}
          {isHome && (
            <div className="w-10 h-10 rounded-full overflow-hidden ring-2 ring-mf-primary-container dark:ring-emerald-800/50">
              <img
                src={PROFILE_IMAGE_URL}
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
          )}
          {(isHome || title) && (
            <div>
              {isHome && (
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-400">
                  {greeting}
                </p>
              )}
              <h1 className="font-[var(--font-manrope)] font-bold text-xl text-mf-on-surface dark:text-stone-100">
                {title ?? (isHome ? "MindFlow" : "")}
              </h1>
            </div>
          )}
        </div>

        {/* Right section */}
        <div className="flex items-center gap-1">
          {(isHome || !showBack) && (
            <button
              className="relative flex items-center justify-center w-10 h-10 rounded-full hover:bg-mf-surface-container-high dark:hover:bg-white/5 transition-colors"
              aria-label="Notifications"
            >
              <MaterialIcon
                icon="notifications"
                className="text-mf-on-surface-variant dark:text-stone-400"
                size="md"
              />
              <span className="absolute top-2 right-2 w-2 h-2 bg-mf-error rounded-full" />
            </button>
          )}
          {rightAction}
        </div>
      </div>
    </header>
  );
}
