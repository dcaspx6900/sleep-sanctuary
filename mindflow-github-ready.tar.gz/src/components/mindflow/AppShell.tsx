"use client";

import { useAppStore, HIDE_TOPBAR_VIEWS } from "@/lib/store";
import TopAppBar from "./TopAppBar";
import BottomNavBar from "./BottomNavBar";
import HomePage from "./pages/HomePage";
import LibraryPage from "./pages/LibraryPage";
import PlayerPage from "./pages/PlayerPage";
import ReflectionPage from "./pages/ReflectionPage";
import ProgressPage from "./pages/ProgressPage";
import SleepPage from "./pages/SleepPage";
import OnboardingPage from "./pages/OnboardingPage";
import SettingsPage from "./pages/SettingsPage";
import EcosystemPage from "./pages/EcosystemPage";
import DownloadsPage from "./pages/DownloadsPage";
import SubscriptionPage from "./pages/SubscriptionPage";

export default function AppShell() {
  const { currentView } = useAppStore();

  const showBack = ![
    "home",
    "library",
    "progress",
    "settings",
    "onboarding",
    "sleep",
  ].includes(currentView);

  const showAppBar =
    !HIDE_TOPBAR_VIEWS.includes(currentView);

  return (
    <div className="min-h-screen transition-colors duration-300 bg-mf-surface text-mf-on-surface dark:bg-[#0e0e0d] dark:text-stone-100">
      {showAppBar && <TopAppBar showBack={showBack} />}

      <main className="max-w-lg mx-auto relative">
        <div className="animate-mf-fade-up" key={currentView}>
          {currentView === "onboarding" && <OnboardingPage />}
          {currentView === "home" && <HomePage />}
          {currentView === "library" && <LibraryPage />}
          {currentView === "player" && <PlayerPage />}
          {currentView === "reflection" && <ReflectionPage />}
          {currentView === "progress" && <ProgressPage />}
          {currentView === "sleep" && <SleepPage />}
          {currentView === "settings" && <SettingsPage />}
          {currentView === "ecosystem" && <EcosystemPage />}
          {currentView === "downloads" && <DownloadsPage />}
          {currentView === "subscription" && <SubscriptionPage />}
        </div>
      </main>

      <BottomNavBar />
    </div>
  );
}
