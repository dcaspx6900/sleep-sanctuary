"use client";

import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";
import { Switch } from "@/components/ui/switch";

export default function EcosystemPage() {
  const { setView } = useAppStore();

  return (
    <div className="px-5 pb-28">
      {/* Breadcrumb */}
      <section className="pt-3 pb-4">
        <button
          onClick={() => setView("settings")}
          className="flex items-center gap-1 text-sm text-mf-primary dark:text-emerald-400 hover:underline"
        >
          <MaterialIcon icon="arrow_back" size="sm" />
          <span>Settings</span>
        </button>
      </section>

      {/* Title */}
      <section className="pb-5">
        <h1 className="text-2xl font-[var(--font-manrope)] font-bold text-mf-on-surface dark:text-stone-100 mb-1">
          Ecosystem
        </h1>
        <p className="text-sm text-mf-on-surface-variant dark:text-stone-400 leading-relaxed">
          Connect your devices and services for a seamless meditation experience.
        </p>
      </section>

      {/* Gemini Insight */}
      <section className="pb-5">
        <div className="rounded-2xl bg-mf-secondary-container/30 dark:bg-blue-900/20 border-l-4 border-mf-secondary dark:border-blue-500 p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center shrink-0 mt-0.5">
              <MaterialIcon icon="auto_awesome" filled className="text-white" size="sm" />
            </div>
            <div>
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-200 mb-1">
                Gemini Insight
              </p>
              <p className="text-xs text-mf-on-surface-variant dark:text-stone-400 leading-relaxed">
                Your meditation patterns adapt using on-device AI. All personal data stays
                private — insights are processed locally and never leave your device.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Wear OS Card (highlighted) */}
      <section className="pb-4">
        <div className="rounded-2xl p-5 relative overflow-hidden bg-mf-surface-container-low dark:bg-stone-900/50">
          {/* Gradient border */}
          <div className="absolute inset-0 rounded-2xl p-[1px] pointer-events-none" style={{ background: "linear-gradient(135deg, #4c645b, #436379, #7d5731)" }}>
            <div className="w-full h-full rounded-2xl bg-mf-surface-container-low dark:bg-stone-900/50" />
          </div>
          <div className="relative flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-mf-primary-container dark:bg-emerald-900/30 flex items-center justify-center shrink-0">
              <MaterialIcon icon="watch" className="text-mf-on-primary-container dark:text-emerald-400" size="xl" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                Wear OS
              </p>
              <p className="text-xs text-mf-on-surface-variant dark:text-stone-400 mt-0.5">
                Track stress & HRV during sessions
              </p>
            </div>
            <button className="shrink-0 px-4 py-2 rounded-full mf-gradient text-white text-xs font-semibold font-[var(--font-manrope)] hover:shadow-lg transition-all">
              Pair Device
            </button>
          </div>
        </div>
      </section>

      {/* Connection List */}
      <section className="pb-5">
        <div className="rounded-2xl bg-mf-surface-container-low dark:bg-stone-900/50 divide-y divide-mf-outline-variant/20 dark:divide-white/5 overflow-hidden">
          {/* Google Calendar */}
          <div className="flex items-center justify-between px-4 py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                <MaterialIcon icon="calendar_month" className="text-mf-secondary dark:text-blue-400" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">
                  Google Calendar
                </p>
                <p className="text-xs text-mf-primary dark:text-emerald-400 font-medium flex items-center gap-1">
                  <MaterialIcon icon="check_circle" filled size="sm" className="text-mf-primary dark:text-emerald-400" />
                  Connected
                </p>
              </div>
            </div>
            <Switch defaultChecked className="data-[state=checked]:bg-mf-primary dark:data-[state=checked]:bg-emerald-600" />
          </div>

          {/* Health Connect */}
          <div className="flex items-center justify-between px-4 py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                <MaterialIcon icon="favorite" className="text-mf-error dark:text-red-400" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">
                  Health Connect
                </p>
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">
                  Heart rate, sleep data
                </p>
              </div>
            </div>
            <MaterialIcon icon="open_in_new" className="text-mf-on-surface-variant dark:text-stone-500" size="sm" />
          </div>

          {/* Privacy */}
          <div className="flex items-center justify-between px-4 py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                <MaterialIcon icon="shield" className="text-mf-on-surface-variant dark:text-stone-400" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">
                  Privacy & Security
                </p>
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">
                  Data & permissions
                </p>
              </div>
            </div>
            <MaterialIcon icon="chevron_right" className="text-mf-on-surface-variant dark:text-stone-500" size="sm" />
          </div>
        </div>
      </section>

      {/* Footer */}
      <section>
        <div className="flex items-center justify-center gap-6 py-4 border-t border-mf-outline-variant/20 dark:border-white/5">
          <MaterialIcon icon="watch" className="text-mf-on-surface-variant/30 dark:text-stone-600" size="sm" />
          <MaterialIcon icon="devices" className="text-mf-on-surface-variant/30 dark:text-stone-600" size="sm" />
          <MaterialIcon icon="bluetooth" className="text-mf-on-surface-variant/30 dark:text-stone-600" size="sm" />
          <MaterialIcon icon="health_and_safety" className="text-mf-on-surface-variant/30 dark:text-stone-600" size="sm" />
        </div>
      </section>
    </div>
  );
}
