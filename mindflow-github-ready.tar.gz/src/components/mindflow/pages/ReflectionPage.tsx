"use client";

import { useState } from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

export default function ReflectionPage() {
  const { setView } = useAppStore();
  const [journalText, setJournalText] = useState("");

  return (
    <div className="px-5 pb-28">
      {/* Session Complete Badge */}
      <section className="pt-4 pb-4">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-mf-secondary-container dark:bg-blue-900/30">
          <MaterialIcon icon="check_circle" filled className="text-mf-on-secondary-container dark:text-blue-400" size="sm" />
          <span className="text-sm font-semibold text-mf-on-secondary-container dark:text-blue-300 font-[var(--font-manrope)]">
            Session Complete
          </span>
        </div>
      </section>

      {/* Title */}
      <section className="pb-5">
        <h1 className="text-2xl font-[var(--font-manrope)] font-bold text-mf-on-surface dark:text-stone-100 mb-2">
          Breath of Clarity
        </h1>
        <p className="text-sm text-mf-on-surface-variant dark:text-stone-400 leading-relaxed">
          You&apos;ve completed 20 minutes of guided breathwork. Your coherence improved
          by 12% during this session.
        </p>
      </section>

      {/* AI Reflection Prompt Card */}
      <section className="pb-5">
        <div className="rounded-2xl p-5 bg-mf-surface-container-low dark:bg-stone-900/60 border border-mf-outline-variant/20 dark:border-white/5">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center shrink-0">
              <MaterialIcon icon="auto_awesome" filled className="text-white" size="sm" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[10px] font-semibold text-mf-on-surface-variant dark:text-stone-500 uppercase tracking-wider">
                  Gemini Reflection
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <p className="text-sm text-mf-on-surface dark:text-stone-200 leading-relaxed">
                Reflecting on your Focus session... What one thing are you grateful for
                right now?
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Journal Textarea */}
      <section className="pb-5">
        <label className="text-xs font-semibold text-mf-on-surface-variant dark:text-stone-500 uppercase tracking-wider mb-2 block">
          Your Reflection
        </label>
        <div className="relative">
          <textarea
            value={journalText}
            onChange={(e) => setJournalText(e.target.value)}
            placeholder="Write your thoughts here..."
            rows={4}
            className="w-full px-4 py-3 rounded-2xl bg-mf-surface-container-low dark:bg-stone-900/60 text-mf-on-surface dark:text-stone-100 text-sm placeholder:text-mf-on-surface-variant/50 dark:placeholder:text-stone-600 border-b-2 border-mf-outline-variant/30 dark:border-white/10 focus:border-mf-primary dark:focus:border-emerald-400 focus:outline-none transition-colors resize-none leading-relaxed"
          />
        </div>
      </section>

      {/* Stats Grid */}
      <section className="pb-6">
        <div className="grid grid-cols-2 gap-3">
          {/* Streak */}
          <div className="rounded-2xl p-4 bg-mf-surface-container-low dark:bg-stone-900/60">
            <div className="flex items-center gap-2 mb-3">
              <MaterialIcon icon="local_fire_department" filled className="text-mf-tertiary dark:text-amber-400" size="sm" />
              <span className="text-[10px] font-semibold text-mf-on-surface-variant dark:text-stone-500 uppercase tracking-wider">
                Session Streak
              </span>
            </div>
            <p className="text-2xl font-[var(--font-manrope)] font-bold text-mf-on-surface dark:text-stone-100 mb-2">
              12 Days
            </p>
            {/* Mini bar chart */}
            <div className="flex items-end gap-1 h-8">
              {[40, 65, 55, 80, 70, 90, 60, 85, 75, 95, 80, 100].map((h, i) => (
                <div
                  key={i}
                  className={`flex-1 rounded-sm ${i === 11 ? "bg-mf-primary dark:bg-emerald-400" : "bg-mf-primary/20 dark:bg-emerald-400/20"}`}
                  style={{ height: `${h}%` }}
                />
              ))}
            </div>
          </div>

          {/* Mindfulness Score */}
          <div className="rounded-2xl p-4 bg-mf-tertiary-container/40 dark:bg-amber-900/20">
            <div className="flex items-center gap-2 mb-3">
              <MaterialIcon icon="psychology" filled className="text-mf-tertiary dark:text-amber-400" size="sm" />
              <span className="text-[10px] font-semibold text-mf-on-surface-variant dark:text-stone-500 uppercase tracking-wider">
                Mindfulness
              </span>
            </div>
            <p className="text-2xl font-[var(--font-manrope)] font-bold text-mf-on-surface dark:text-stone-100 mb-2">
              94%
            </p>
            <div className="w-full h-2 rounded-full bg-mf-surface-container-high dark:bg-stone-800 overflow-hidden">
              <div
                className="h-full rounded-full bg-mf-tertiary dark:bg-amber-400 animate-mf-grow-width"
                style={{ width: "94%" }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Action Buttons */}
      <section className="flex gap-3">
        <button
          onClick={() => setView("home")}
          className="flex-1 h-14 rounded-full mf-gradient text-white text-sm font-semibold font-[var(--font-manrope)] shadow-lg shadow-mf-primary/20 hover:shadow-xl transition-all active:scale-[0.98]"
        >
          Save Reflection
        </button>
        <button
          onClick={() => setView("progress")}
          className="flex-1 h-14 rounded-full bg-mf-surface-container-high dark:bg-stone-800 text-mf-on-surface dark:text-stone-200 text-sm font-semibold font-[var(--font-manrope)] hover:bg-mf-surface-container-highest dark:hover:bg-stone-700 transition-all active:scale-[0.98]"
        >
          Share Journey
        </button>
      </section>
    </div>
  );
}
