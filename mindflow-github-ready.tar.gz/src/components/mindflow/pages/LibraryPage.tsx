"use client";

import { useState } from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

const focusFlows = [
  {
    title: "Deep Work Pulse",
    duration: "15 MIN",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuBEQeU_KYQICYGzaF16ubkT-9EtT4VH2WRUkSDbw0U_JH63UE_1reJp9YcEuS4WK7rLC5mjLbzwDqHdzz7WgP9X3itd-6S-70RN95bKMN9UHxINkNS0CMYFUzlnlfaY6BD2e-POz76cHYG2DKM4dGFpN-uZRKOfgEQKwsJhVYzO404NuC36XJGd92xhSyp59Gh7Ws_hjGZeLcdbs1QhJ7r8Qt1kBUjI46MTBEz8KKFRUSs5sp_6ZyG-vP0h6XG8Mm6kmxp5LTkbDTo",
  },
  {
    title: "Morning Clarity",
    duration: "10 MIN",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAJwi9tEq4SBpT_OEjg5WVEQOUziRSllJjYKx62qMEO0hnTBRr_5-Cyhy9_O0i-wcwJ2IErVbXUGh3pcirF_4mw7WjZMbECaXJMv1dFyeuRu0avWucDVYMLUWLqriqQtAuGaDdRQsPdHaPa0c9wcV_faxISS3LUvvgqqpQ2qKHYi6u9yRONtOzjNwX8pRdnyJ2e5Ta48C6zqtRS9PjZ7SysOWfoX2JPqxjOXUkv2xDi4W0GwzHhzpZZIL2iH6nUiWBIjlFPV9dwVsU",
  },
  {
    title: "Creative Spark",
    duration: "20 MIN",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuChmAkG_6BlIFf2r_XSPFfy2vZfkg3OPNTFKpq7kNbbynrE06C98qtikNIUC1_MRKshWNouHn5w7E_SjXOs5VA_br5f8ck0-KXtdbfpQB9ORxXfHXSsmlwjOyTTBi8L6COoDJElkPN7BL5VNeoIMwxnosQmEZFYqdB6HOzskUCX4U0emeLTuY6wrJFt9UJs0mzpzVwn2Wef2FJkjFYFYaix3BDJBCNHg5tc01OXePiac7yeHWEkw0SVh2RjDwUI26MDS34Fd90fZSs",
  },
  {
    title: "Flow State Entry",
    duration: "12 MIN",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDWsYKxvciR4VCwAFrUxgByYSyrNLfY2s62OTnLojp_HuSBomYDsMsTiinbuvLXGvLYMEJalROrG3OpLXVim6Rhly70RoGUMqTUBFwzwF3Gc2yDBGic7PW4xYJzxMfXt8Y9BUxWYPd6bmZFGUuoLoSpSNlNbKJRnDnSeiTRizOg2o4-KDM0zFSmMEuxfxAGWwcgwmFK9kXp1TCwaWz5Hmm_FRmSM6Fwxc1O55UF6jZTknwAjyVN4-nndGwfYCAprF3nEXA78Ju_wSQ",
  },
];

const stressDeescalation = [
  { title: "Calm Storm", duration: "12 min", icon: "thunderstorm", color: "from-blue-900/40 to-slate-900/40" },
  { title: "Ocean Drift", duration: "18 min", icon: "waves", color: "from-cyan-900/40 to-blue-900/40" },
  { title: "Forest Bath", duration: "15 min", icon: "forest", color: "from-emerald-900/40 to-teal-900/40" },
];

const deepSleep = [
  { title: "Midnight Garden", duration: "45 min", icon: "bedtime", color: "bg-gradient-to-br from-[#1a1a2e] to-[#16213e]" },
  { title: "Starfield", duration: "60 min", icon: "dark_mode", color: "bg-gradient-to-br from-[#0f0c29] to-[#302b63]" },
];

export default function LibraryPage() {
  const { setView } = useAppStore();
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="max-w-7xl mx-auto px-5 pb-28">
      {/* Search bar */}
      <section className="pt-3 pb-4">
        <div className="relative">
          <MaterialIcon
            icon="search"
            className="absolute left-4 top-1/2 -translate-y-1/2 text-mf-on-surface-variant dark:text-stone-500"
            size="md"
          />
          <input
            type="text"
            placeholder="Search meditations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-full bg-mf-surface-container-low dark:bg-stone-900/60 text-mf-on-surface dark:text-stone-100 text-sm placeholder:text-mf-on-surface-variant dark:placeholder:text-stone-500 border border-mf-outline-variant/20 dark:border-white/5 focus:outline-none focus:ring-2 focus:ring-mf-primary/30 dark:focus:ring-emerald-400/30 transition-all"
          />
        </div>
      </section>

      {/* Hero: Today's Pick */}
      <section className="pb-6">
        <h2 className="text-base font-[var(--font-manrope)] font-semibold text-mf-on-surface dark:text-stone-100 mb-3">
          Today&apos;s Pick
        </h2>
        <button
          onClick={() => setView("player")}
          className="w-full rounded-2xl overflow-hidden relative group"
        >
          <div className="aspect-[16/9] relative">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDDUcsCv6H_yrBjuy3hbdO3KTRvD2QNQ-TRizfNNyQPgM8Rtco7MHf7qGRsL5X3ZS2Fz0jtgH3Xf_Hf-VimwStu2ZG4oKHX-bEpPbKWICivqrFVThGQZ8oKoqYzYOs2vzHWyFrGTyutienNvMH4NfKlRyaqyBD1-4exM3v0aceKbwQ4PB-cN5F16BPgqbxbeHb3x089BrI-4wf2xwOHgiRNBPwU-nhrZ6cYcIkgAkRlR4HO6hbO6izdmgO1TWdAwqAHgjIq_5xFZDo"
              alt="Golden Hour Calm"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-5">
              <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-[10px] text-white font-medium backdrop-blur-sm mb-2 inline-block">
                RECOMMENDED
              </span>
              <h3 className="font-[var(--font-manrope)] font-bold text-xl text-white mb-1">
                Golden Hour Calm
              </h3>
              <p className="text-sm text-white/60">Guided Meditation · 20 min</p>
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:bg-white/30 transition-colors">
              <MaterialIcon icon="play_arrow" filled className="text-white text-4xl ml-1" />
            </div>
          </div>
        </button>
      </section>

      {/* Focus Flows - Horizontal scroll */}
      <section className="pb-6">
        <h2 className="text-base font-[var(--font-manrope)] font-semibold text-mf-on-surface dark:text-stone-100 mb-3">
          Focus Flows
        </h2>
        <div className="flex gap-3 overflow-x-auto hide-scrollbar -mx-5 px-5">
          {focusFlows.map((item, i) => (
            <button
              key={i}
              onClick={() => setView("player")}
              className="flex-shrink-0 w-40 rounded-2xl overflow-hidden relative group"
            >
              <div className="aspect-[4/5] relative">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-3">
                  <h3 className="text-sm font-semibold text-white font-[var(--font-manrope)]">
                    {item.title}
                  </h3>
                  <span className="text-[10px] text-white/60 font-medium">
                    {item.duration}
                  </span>
                </div>
                <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <MaterialIcon icon="play_arrow" filled className="text-white text-lg ml-0.5" />
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Stress De-escalation - Horizontal scroll landscape */}
      <section className="pb-6">
        <h2 className="text-base font-[var(--font-manrope)] font-semibold text-mf-on-surface dark:text-stone-100 mb-3">
          Stress De-escalation
        </h2>
        <div className="flex gap-3 overflow-x-auto hide-scrollbar -mx-5 px-5">
          {stressDeescalation.map((item, i) => (
            <button
              key={i}
              onClick={() => setView("player")}
              className="flex-shrink-0 w-60 rounded-2xl overflow-hidden relative group"
            >
              <div className={`h-48 bg-gradient-to-br ${item.color} p-4 flex flex-col justify-between`}>
                <div className="flex items-center justify-between">
                  <MaterialIcon icon={item.icon} filled className="text-white/40 text-3xl" />
                  <span className="text-[10px] text-white/60 font-medium px-2 py-0.5 rounded-full bg-white/10">
                    {item.duration}
                  </span>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white font-[var(--font-manrope)]">
                    {item.title}
                  </h3>
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Deep Sleep Grid */}
      <section className="pb-6">
        <h2 className="text-base font-[var(--font-manrope)] font-semibold text-mf-on-surface dark:text-stone-100 mb-3">
          Deep Sleep
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {deepSleep.map((item, i) => (
            <button
              key={i}
              onClick={() => setView("sleep")}
              className="rounded-2xl overflow-hidden relative group text-left"
            >
              <div className={`${item.color} p-4 flex flex-col justify-between h-40`}>
                <MaterialIcon icon={item.icon} filled className="text-white/30 text-3xl" />
                <div>
                  <h3 className="text-sm font-semibold text-white font-[var(--font-manrope)]">
                    {item.title}
                  </h3>
                  <span className="text-[10px] text-white/50 font-medium">
                    {item.duration}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
