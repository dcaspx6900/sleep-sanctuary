"use client";

import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

interface DownloadItem {
  id: string;
  title: string;
  duration: string;
  size: string;
  status: "downloaded" | "downloading" | "queued";
  progress?: number;
  color: string;
}

const downloads: DownloadItem[] = [
  { id: "1", title: "Morning Resilience", duration: "15 mins", size: "42 MB", status: "downloaded", color: "bg-mf-primary-container dark:bg-emerald-900/30" },
  { id: "2", title: "Ocean Breathwork", duration: "20 mins", size: "64 MB", status: "downloading", progress: 65, color: "bg-mf-secondary-container dark:bg-blue-900/30" },
  { id: "3", title: "Sunset Gratitude", duration: "12 mins", size: "28 MB", status: "queued", color: "bg-mf-tertiary-container dark:bg-amber-900/30" },
  { id: "4", title: "Deep Sleep Forest", duration: "45 mins", size: "88 MB", status: "downloaded", color: "bg-mf-primary-container dark:bg-emerald-900/30" },
  { id: "5", title: "Focus Flow", duration: "25 mins", size: "55 MB", status: "downloaded", color: "bg-mf-secondary-container dark:bg-blue-900/30" },
];

export default function DownloadsPage() {
  const { setView } = useAppStore();

  return (
    <div className="px-5 pb-28">
      {/* Breadcrumb */}
      <section className="pt-3 pb-4">
        <button
          onClick={() => setView("settings")}
          className="flex items-center gap-1 text-sm text-mf-primary dark:text-emerald-400 hover:underline"
        >
          <MaterialIcon icon="arrow_back" size="sm" />
          <span>Settings</span>
        </button>
      </section>

      {/* Title */}
      <section className="pb-5">
        <h1 className="text-2xl font-[var(--font-manrope)] font-bold text-mf-on-surface dark:text-stone-100 mb-1">
          Offline Sanctuary
        </h1>
        <p className="text-sm text-mf-on-surface-variant dark:text-stone-400">
          Your downloaded moments of peace, available anywhere.
        </p>
      </section>

      {/* Storage Bar */}
      <section className="pb-5">
        <div className="rounded-2xl p-4 bg-mf-surface-container-low dark:bg-stone-900/50">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100">
                Storage Used
              </p>
              <p className="text-xs text-mf-on-surface-variant dark:text-stone-500 mt-0.5">
                1.2 GB / 5 GB
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-mf-primary-container/60 dark:bg-emerald-900/30 text-[11px] font-semibold text-mf-on-primary-container dark:text-emerald-400">
              24 Sessions
            </span>
          </div>
          <div className="w-full h-2.5 rounded-full bg-mf-surface-container-highest dark:bg-stone-800 overflow-hidden">
            <div
              className="h-full rounded-full mf-gradient animate-mf-grow-width"
              style={{ width: "24%" }}
            />
          </div>
        </div>
      </section>

      {/* Downloads List */}
      <section className="pb-5">
        <h3 className="text-[10px] font-semibold text-mf-on-surface-variant dark:text-stone-500 mb-3 px-1 uppercase tracking-widest">
          Recently Saved
        </h3>
        <div className="space-y-2.5">
          {downloads.map((item) => (
            <div
              key={item.id}
              className="flex items-center gap-3 p-3 rounded-2xl bg-mf-surface-container-low dark:bg-stone-900/50"
            >
              <div className={`w-12 h-12 rounded-xl ${item.color} flex items-center justify-center shrink-0`}>
                <MaterialIcon
                  icon={
                    item.status === "downloaded"
                      ? "cloud_done"
                      : item.status === "downloading"
                        ? "downloading"
                        : "schedule"
                  }
                  className="text-mf-on-surface-variant dark:text-stone-400"
                  size="lg"
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100 truncate">
                  {item.title}
                </p>
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-500 mt-0.5">
                  {item.duration} · {item.size}
                </p>
                {item.status === "downloading" && (
                  <div className="mt-1.5 w-full h-1.5 rounded-full bg-mf-surface-container-highest dark:bg-stone-800 overflow-hidden">
                    <div
                      className="h-full rounded-full mf-gradient transition-all duration-500"
                      style={{ width: `${item.progress}%` }}
                    />
                  </div>
                )}
                {item.status === "queued" && (
                  <p className="text-[10px] text-mf-on-surface-variant/60 dark:text-stone-600 mt-1 flex items-center gap-1">
                    <MaterialIcon icon="wifi" size="sm" className="text-mf-on-surface-variant/40 dark:text-stone-700" />
                    Waiting for Wi-Fi
                  </p>
                )}
              </div>
              <div className="shrink-0">
                {item.status === "downloaded" && (
                  <MaterialIcon icon="check_circle" filled className="text-mf-primary dark:text-emerald-400" size="md" />
                )}
                {item.status === "downloading" && (
                  <div className="w-8 h-8 rounded-full flex items-center justify-center">
                    <MaterialIcon icon="downloading" className="text-mf-secondary dark:text-blue-400" size="md" />
                  </div>
                )}
                {item.status === "queued" && (
                  <MaterialIcon icon="schedule" className="text-mf-on-surface-variant/40 dark:text-stone-600" size="md" />
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Space-Saving Mode CTA */}
      <section>
        <div className="rounded-2xl bg-gradient-to-br from-mf-primary-container/30 to-mf-secondary-container/20 dark:from-emerald-900/20 dark:to-blue-900/10 p-5 border border-mf-primary/10 dark:border-emerald-800/20">
          <div className="flex items-start gap-3">
            <div className="w-11 h-11 rounded-xl bg-mf-surface-container-lowest dark:bg-stone-800/50 flex items-center justify-center shrink-0">
              <MaterialIcon icon="cleaning_services" className="text-mf-primary dark:text-emerald-400" size="lg" />
            </div>
            <div className="flex-1">
              <p className="font-[var(--font-manrope)] font-bold text-sm text-mf-on-surface dark:text-stone-100">
                Space-Saving Mode
              </p>
              <p className="text-xs text-mf-on-surface-variant dark:text-stone-400 mt-1 leading-relaxed">
                Automatically remove listened sessions and keep your most-used meditations offline.
              </p>
              <button className="mt-3 px-5 py-2 rounded-full mf-gradient text-white text-xs font-semibold hover:shadow-lg transition-all">
                Enable Auto-Clean
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
