"use client";

import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

const features = [
  { icon: "auto_awesome", label: "AI Adaptive Sessions", desc: "Real-time personalization" },
  { icon: "watch", label: "Wear OS Sync", desc: "Biometric tracking" },
  { icon: "edit_note", label: "Unlimited Journal", desc: "AI-powered reflections" },
  { icon: "cloud_download", label: "Offline Access", desc: "Download any session" },
  { icon: "trending_up", label: "Advanced Analytics", desc: "Deep wellbeing insights" },
  { icon: "palette", label: "Premium Soundscapes", desc: "Curated ambient audio" },
];

export default function SubscriptionPage() {
  const { setView } = useAppStore();

  return (
    <div className="px-5 pb-28">
      {/* Breadcrumb */}
      <section className="pt-3 pb-4">
        <button
          onClick={() => setView("settings")}
          className="flex items-center gap-1 text-sm text-mf-primary dark:text-emerald-400 hover:underline"
        >
          <MaterialIcon icon="arrow_back" size="sm" />
          <span>Settings</span>
        </button>
      </section>

      {/* Title */}
      <section className="pb-5">
        <h1 className="text-2xl font-[var(--font-manrope)] font-bold text-mf-on-surface dark:text-stone-100 mb-1">
          Membership
        </h1>
        <p className="text-sm text-mf-on-surface-variant dark:text-stone-400">
          Manage your subscription and billing.
        </p>
      </section>

      {/* Premium Plan Card */}
      <section className="pb-5">
        <div className="rounded-2xl p-5 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #4c645b 0%, #3a5249 50%, #2d4a3e 100%)" }}>
          <div className="absolute inset-0 opacity-10">
            <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-mf-primary-container/40 blur-3xl" />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-4">
              <MaterialIcon icon="workspace_premium" filled className="text-mf-primary-container" />
              <span className="text-[11px] font-semibold text-mf-primary-container/80 uppercase tracking-wider">
                Premium Plan
              </span>
            </div>
            <div className="flex items-baseline gap-1 mb-1">
              <span className="text-4xl font-[var(--font-manrope)] font-bold text-white">$9.99</span>
              <span className="text-sm text-white/50">/month</span>
            </div>
            <p className="text-xs text-white/40 mb-5">
              Next renewal: January 15, 2025
            </p>
            <button className="w-full py-3 rounded-full bg-white/10 text-white text-sm font-semibold font-[var(--font-manrope)] hover:bg-white/20 transition-colors border border-white/10">
              Update Payment Method
            </button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="pb-6">
        <h2 className="text-base font-[var(--font-manrope)] font-semibold text-mf-on-surface dark:text-stone-100 mb-3">
          Included Features
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {features.map((f, i) => (
            <div
              key={i}
              className="rounded-2xl p-4 bg-mf-surface-container-low dark:bg-stone-900/50"
            >
              <div className="w-10 h-10 rounded-xl bg-mf-primary-container/50 dark:bg-emerald-900/20 flex items-center justify-center mb-3">
                <MaterialIcon icon={f.icon} className="text-mf-primary dark:text-emerald-400" size="sm" />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                {f.label}
              </p>
              <p className="text-[11px] text-mf-on-surface-variant dark:text-stone-500 mt-0.5">
                {f.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Secure & Transparent */}
      <section>
        <div className="rounded-2xl p-5 bg-mf-surface-container-low dark:bg-stone-900/50 border border-mf-outline-variant/10 dark:border-white/5">
          <div className="flex items-center gap-2 mb-4">
            <MaterialIcon icon="verified_user" className="text-mf-primary dark:text-emerald-400" size="sm" />
            <span className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
              Secure & Transparent
            </span>
          </div>
          <div className="space-y-3">
            <button className="flex items-center gap-3 w-full text-left hover:bg-mf-surface-container-high dark:hover:bg-stone-800/50 rounded-xl p-2 -m-2 transition-colors">
              <MaterialIcon icon="receipt_long" className="text-mf-on-surface-variant dark:text-stone-400" size="sm" />
              <span className="text-sm text-mf-on-surface dark:text-stone-200">
                Download Invoices
              </span>
            </button>
            <button className="flex items-center gap-3 w-full text-left hover:bg-mf-surface-container-high dark:hover:bg-stone-800/50 rounded-xl p-2 -m-2 transition-colors">
              <MaterialIcon icon="cancel" className="text-mf-error dark:text-red-400" size="sm" />
              <span className="text-sm text-mf-error dark:text-red-400">
                Cancel Trial
              </span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
