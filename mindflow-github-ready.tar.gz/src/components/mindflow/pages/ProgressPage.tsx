"use client";

import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

const milestones = [
  {
    title: "The Silent Observer",
    desc: "Complete 10 sessions",
    icon: "visibility",
    collected: true,
  },
  {
    title: "First Sprout",
    desc: "Begin your journey",
    icon: "eco",
    collected: true,
  },
  {
    title: "Deep Rooted",
    desc: "7.2 / 10h meditation",
    icon: "park",
    collected: false,
    progress: 72,
  },
];

const moodTrend = [45, 60, 55, 70, 65, 80, 75, 85, 70, 90];

export default function ProgressPage() {
  const { setView } = useAppStore();

  return (
    <div className="px-5 pb-28">
      {/* Virtual Forest Hero */}
      <section className="pt-3 pb-5">
        <div className="rounded-2xl overflow-hidden relative h-48">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAdIVzrwbxSzeCoPXlSM84PAB-zDR9pU0w620rdW4jY3POQFoIYiUfoWALoRtgwZWKIEjvCGNFFYZ4g1NTUMMJBiyRvwW2cVN4JGT02E4YA3jSvT5z6VuVXsV1TociDiT2S5BgLAy1Jro4mNb_u8ziAg8iJWBfyX6DEOUsfXPvCDswZvHKPCkhCRQcWnoUcNdYO_W37iLZ9VYlCoo6IvIjtolNqjUbFOm7jF1b-i5Oqh8C5kJoVIKM-qE4XGk0gMJrDf9klKo3cLqE"
            alt="Your Sacred Grove"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
          {/* Glass overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <h2 className="font-[var(--font-manrope)] font-bold text-lg text-white mb-2">
              Your Sacred Grove
            </h2>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-2 rounded-full bg-white/20 overflow-hidden">
                <div
                  className="h-full rounded-full bg-emerald-400 animate-mf-grow-width"
                  style={{ width: "72%" }}
                />
              </div>
              <span className="text-xs font-semibold text-emerald-300">72%</span>
            </div>
            <p className="text-[10px] text-white/50 mt-1">Growth progress</p>
          </div>
        </div>
      </section>

      {/* Bento Grid Stats */}
      <section className="pb-5">
        <div className="grid grid-cols-3 gap-2.5">
          {/* Streak */}
          <div className="rounded-2xl p-4 bg-mf-surface-container-low dark:bg-stone-900/50 text-center">
            <MaterialIcon icon="local_fire_department" filled className="text-mf-tertiary dark:text-amber-400 mb-2" size="md" />
            <p className="text-xl font-[var(--font-manrope)] font-bold text-mf-on-surface dark:text-stone-100">
              12
            </p>
            <p className="text-[10px] text-mf-on-surface-variant dark:text-stone-500 uppercase tracking-wider">
              Days
            </p>
          </div>

          {/* Total */}
          <div className="rounded-2xl p-4 bg-mf-surface-container-low dark:bg-stone-900/50 text-center">
            <MaterialIcon icon="schedule" filled className="text-mf-secondary dark:text-blue-400 mb-2" size="md" />
            <p className="text-xl font-[var(--font-manrope)] font-bold text-mf-on-surface dark:text-stone-100">
              840m
            </p>
            <p className="text-[10px] text-mf-on-surface-variant dark:text-stone-500 uppercase tracking-wider">
              Total
            </p>
          </div>

          {/* Mood Trend */}
          <div className="rounded-2xl p-4 bg-mf-surface-container-low dark:bg-stone-900/50">
            <MaterialIcon icon="trending_up" filled className="text-mf-primary dark:text-emerald-400 mb-2" size="md" />
            <div className="flex items-end gap-0.5 h-10">
              {moodTrend.map((h, i) => (
                <div
                  key={i}
                  className={`flex-1 rounded-sm ${i === moodTrend.length - 1 ? "bg-mf-primary dark:bg-emerald-400" : "bg-mf-primary/20 dark:bg-emerald-400/20"}`}
                  style={{ height: `${h}%` }}
                />
              ))}
            </div>
            <p className="text-[10px] text-mf-on-surface-variant dark:text-stone-500 uppercase tracking-wider mt-1 text-center">
              Mood
            </p>
          </div>
        </div>
      </section>

      {/* Milestones */}
      <section className="pb-6">
        <h2 className="text-base font-[var(--font-manrope)] font-semibold text-mf-on-surface dark:text-stone-100 mb-3">
          Milestones
        </h2>
        <div className="space-y-3">
          {milestones.map((m, i) => (
            <div
              key={i}
              className={`flex items-center gap-3 p-4 rounded-2xl transition-all ${
                m.collected
                  ? "bg-mf-surface-container-low dark:bg-stone-900/50"
                  : "bg-mf-surface-container-low dark:bg-stone-900/30 opacity-70"
              }`}
            >
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${
                  m.collected
                    ? "bg-mf-tertiary-container dark:bg-amber-900/30"
                    : "bg-mf-surface-container-high dark:bg-stone-800/50"
                }`}
              >
                <MaterialIcon
                  icon={m.icon}
                  filled={m.collected}
                  className={
                    m.collected
                      ? "text-mf-on-tertiary-container dark:text-amber-400"
                      : "text-mf-on-surface-variant/40 dark:text-stone-600"
                  }
                  size="md"
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-200 font-[var(--font-manrope)]">
                  {m.title}
                </p>
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">
                  {m.desc}
                </p>
                {!m.collected && m.progress && (
                  <div className="mt-2 w-full h-1.5 rounded-full bg-mf-surface-container-highest dark:bg-stone-800 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-mf-outline dark:bg-stone-600"
                      style={{ width: `${m.progress}%` }}
                    />
                  </div>
                )}
              </div>
              {m.collected ? (
                <MaterialIcon icon="check_circle" filled className="text-mf-primary dark:text-emerald-400" size="md" />
              ) : (
                <MaterialIcon icon="lock" className="text-mf-on-surface-variant/30 dark:text-stone-700" size="md" />
              )}
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section>
        <button
          onClick={() => setView("library")}
          className="w-full rounded-2xl p-5 text-left relative overflow-hidden group"
          style={{ background: "linear-gradient(135deg, #4c645b 0%, #3a5249 50%, #2d4a3e 100%)" }}
        >
          <div className="absolute inset-0 opacity-20">
            <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-mf-primary-container/40 blur-3xl" />
          </div>
          <div className="relative z-10 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
              <MaterialIcon icon="spa" filled className="text-mf-primary-container" size="lg" />
            </div>
            <div className="flex-1">
              <p className="font-[var(--font-manrope)] font-bold text-base text-white">
                Deepen Your Practice
              </p>
              <p className="text-xs text-white/60 mt-0.5">
                Explore advanced sessions
              </p>
            </div>
            <MaterialIcon icon="arrow_forward" className="text-white/60 group-hover:text-white transition-colors" />
          </div>
        </button>
      </section>
    </div>
  );
}
