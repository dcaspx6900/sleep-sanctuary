"use client";

import { useState } from "react";
import MaterialIcon from "@/components/MaterialIcon";
import OrganicBackground from "../OrganicBackground";
import { useAppStore } from "@/lib/store";

const moods = [
  { id: "calm", icon: "filter_drama", label: "Calm" },
  { id: "anxious", icon: "waves", label: "Anxious" },
  { id: "focused", icon: "target", label: "Focused" },
  { id: "tired", icon: "nights_stay", label: "Tired" },
];

const moodColors: Record<string, string> = {
  calm: "bg-mf-primary-container dark:bg-emerald-900/40",
  anxious: "bg-mf-secondary-container dark:bg-blue-900/40",
  focused: "bg-mf-tertiary-container dark:bg-amber-900/40",
  tired: "bg-mf-surface-container-high dark:bg-stone-800/40",
};

const moodActiveColors: Record<string, string> = {
  calm: "ring-2 ring-mf-primary dark:ring-emerald-400",
  anxious: "ring-2 ring-mf-secondary dark:ring-blue-400",
  focused: "ring-2 ring-mf-tertiary dark:ring-amber-400",
  tired: "ring-2 ring-mf-on-surface-variant dark:ring-stone-400",
};

export default function HomePage() {
  const { selectedMood, setMood, setView } = useAppStore();
  const [mood, setMoodLocal] = useState<string | null>(null);

  const handleMoodSelect = (id: string) => {
    setMoodLocal(id === mood ? null : id);
    setMood(id === mood ? null : id);
  };

  return (
    <div className="relative">
      <OrganicBackground />
      <div className="relative z-10 px-5 pb-28">
        {/* Hero greeting */}
        <section className="pt-3 pb-5">
          <h2 className="text-2xl font-[var(--font-manrope)] font-bold text-mf-on-surface dark:text-stone-100 mb-4">
            How are you feeling today?
          </h2>
          <div className="grid grid-cols-4 gap-2.5">
            {moods.map((item) => (
              <button
                key={item.id}
                onClick={() => handleMoodSelect(item.id)}
                className={`flex flex-col items-center gap-2 p-3 rounded-2xl transition-all duration-300 ${
                  moodColors[item.id]
                } ${mood === item.id ? moodActiveColors[item.id] + " scale-105" : "hover:scale-105"}`}
              >
                <MaterialIcon
                  icon={item.icon}
                  filled={mood === item.id}
                  className="text-mf-on-surface dark:text-stone-200"
                  size="lg"
                />
                <span className="text-[11px] font-medium text-mf-on-surface-variant dark:text-stone-400">
                  {item.label}
                </span>
              </button>
            ))}
          </div>
        </section>

        {/* Context-Aware Prompt Card */}
        <section className="pb-5">
          <div className="rounded-2xl p-5 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #4c645b 0%, #3a5249 50%, #2d4a3e 100%)" }}>
            <div className="absolute inset-0 opacity-20">
              <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-mf-primary-container/40 blur-3xl" />
            </div>
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-3">
                <MaterialIcon icon="auto_awesome" filled className="text-mf-primary-container" size="sm" />
                <span className="text-[11px] font-semibold text-mf-primary-container/80 uppercase tracking-wider">
                  AI Suggestion
                </span>
              </div>
              <h3 className="font-[var(--font-manrope)] font-bold text-lg text-white mb-1">
                After your 3 PM meeting...
              </h3>
              <p className="text-sm text-white/70 mb-4 leading-relaxed">
                A quick breathwork session to reset your focus and clarity.
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setView("player")}
                  className="px-5 py-2.5 rounded-full bg-mf-primary-container text-[#002019] text-sm font-semibold font-[var(--font-manrope)] hover:bg-mf-primary-fixed transition-colors"
                >
                  Start Session
                </button>
                <button
                  onClick={() => setView("library")}
                  className="px-5 py-2.5 rounded-full bg-white/10 text-white text-sm font-medium hover:bg-white/20 transition-colors"
                >
                  Browse All
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Daily Recommended */}
        <section className="pb-5">
          <h2 className="text-base font-[var(--font-manrope)] font-semibold text-mf-on-surface dark:text-stone-100 mb-3">
            Daily Recommended
          </h2>

          {/* Large Hero Card */}
          <button
            onClick={() => setView("player")}
            className="w-full rounded-2xl overflow-hidden relative mb-3 group"
          >
            <div className="aspect-[16/10] relative">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAfLdUusx8FkUzrdhYcfk5vexXT6L-rROKVIgXIqSivZzHpyrI03MybJjgWaQLnu_7_f5SoifjmWAjBlK5Z0w5NQNT6HN4Os5K7ZNClAGlM7Jul4Cxc7ft6vyH5jcaYJ8wWwZ1XOoLRrIo19Ti2N3GyDdhryvDb27-3VGAKtkbzLUIS3YZpsE4DydWniBcH2M4oTAywZmXubt7zJCReSWwyy571dyC8KCMrVic9W00S22w3UU-8hxR4zDW6o49bQCTJnlxRNGNaLHc"
                alt="Garden of Stillness"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="font-[var(--font-manrope)] font-bold text-lg text-white mb-1">
                  The Garden of Stillness
                </h3>
                <p className="text-xs text-white/60 mb-3">Guided Meditation</p>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-[10px] text-white font-medium backdrop-blur-sm">
                    Adaptive
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-[10px] text-white font-medium backdrop-blur-sm">
                    12 MIN
                  </span>
                </div>
              </div>
              {/* Play button */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-14 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:bg-white/30 transition-colors">
                <MaterialIcon icon="play_arrow" filled className="text-white text-3xl ml-0.5" />
              </div>
            </div>
          </button>

          {/* Smaller cards grid */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setView("sleep")}
              className="rounded-2xl p-4 text-left bg-mf-surface-container-low dark:bg-stone-900/50 hover:bg-mf-surface-container-high dark:hover:bg-stone-800/50 transition-colors"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#1a2f3a] to-[#2a4a5a] flex items-center justify-center mb-3">
                <MaterialIcon icon="self_improvement" filled className="text-[#a0c4ff]" size="lg" />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                Sleep Rituals
              </p>
              <p className="text-xs text-mf-on-surface-variant dark:text-stone-400 mt-0.5">
                Wind down tonight
              </p>
            </button>
            <button
              onClick={() => setView("player")}
              className="rounded-2xl p-4 text-left bg-mf-surface-container-low dark:bg-stone-900/50 hover:bg-mf-surface-container-high dark:hover:bg-stone-800/50 transition-colors"
            >
              <div className="w-11 h-11 rounded-xl bg-mf-primary-container dark:bg-emerald-900/40 flex items-center justify-center mb-3">
                <MaterialIcon icon="psychology" filled className="text-mf-primary dark:text-emerald-400" size="lg" />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                Focus Flow
              </p>
              <p className="text-xs text-mf-on-surface-variant dark:text-stone-400 mt-0.5">
                Sharpen your mind
              </p>
            </button>
          </div>
        </section>

        {/* FAB */}
        <button className="fixed bottom-24 right-5 z-40 w-14 h-14 rounded-full mf-gradient shadow-lg shadow-mf-primary/30 flex items-center justify-center hover:scale-110 transition-transform active:scale-95">
          <MaterialIcon icon="add" filled className="text-white text-2xl" />
        </button>
      </div>
    </div>
  );
}
