"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/store";
import MaterialIcon from "@/components/MaterialIcon";

export default function OnboardingPage() {
  const { onboardingStep, setOnboardingStep, setView } = useAppStore();
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);

  const toggleGoal = (goal: string) => {
    setSelectedGoals((prev) =>
      prev.includes(goal) ? prev.filter((g) => g !== goal) : [...prev, goal]
    );
  };

  const handleContinue = () => {
    if (onboardingStep < 2) {
      setOnboardingStep(onboardingStep + 1);
    } else {
      setView("home");
    }
  };

  const handleSkip = () => {
    setOnboardingStep(2);
  };

  const renderProgressDots = (current: number) => (
    <div className="flex items-center justify-center gap-2">
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className={`h-2 rounded-full transition-all duration-500 ${
            i <= current
              ? "bg-mf-primary dark:bg-emerald-400 w-6"
              : "bg-mf-outline-variant dark:bg-stone-700 w-2"
          }`}
        />
      ))}
    </div>
  );

  // Step 0: Welcome
  if (onboardingStep === 0) {
    return (
      <div className="min-h-screen bg-mf-surface dark:bg-[#0e0e0d] relative overflow-hidden flex flex-col">
        {/* Background organic shapes */}
        <div
          className="absolute top-[-20%] right-[-15%] w-80 h-80 rounded-full animate-mf-pulse-organic pointer-events-none"
          style={{ background: "radial-gradient(circle, rgba(206,233,221,0.4) 0%, transparent 70%)" }}
        />
        <div
          className="absolute bottom-[-10%] left-[-10%] w-72 h-72 rounded-full animate-mf-pulse-organic pointer-events-none"
          style={{
            background: "radial-gradient(circle, rgba(200,230,255,0.3) 0%, transparent 70%)",
            animationDelay: "4s",
          }}
        />

        <div className="relative z-10 flex-1 flex flex-col px-6 pt-14 pb-10">
          {/* Brand */}
          <div className="animate-mf-fade-up mb-8">
            <h1 className="text-xl font-bold text-mf-primary dark:text-emerald-400 font-[var(--font-manrope)] tracking-tight">
              MindFlow
            </h1>
          </div>

          {/* Hero heading */}
          <div className="animate-mf-fade-up stagger-1 mb-3">
            <h2 className="text-[2.75rem] font-extrabold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)] leading-[1.1]">
              Welcome to
              <br />
              your sanctuary.
            </h2>
          </div>

          {/* Subtitle */}
          <p className="text-base text-mf-on-surface-variant dark:text-stone-400 leading-relaxed max-w-sm animate-mf-fade-up stagger-2 mb-8">
            Find clarity in the chaos. Discover personalized meditation that adapts to
            your rhythm, your mood, your life.
          </p>

          {/* Organic visual shape */}
          <div className="relative mx-auto mb-8 animate-mf-scale-up stagger-3">
            <div className="w-52 h-52 rounded-[60%_40%_30%_70%/_60%_30%_70%_40%] overflow-hidden relative shadow-2xl">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAfLdUusx8FkUzrdhYcfk5vexXT6L-rROKVIgXIqSivZzHpyrI03MybJjgWaQLnu_7_f5SoifjmWAjBlK5Z0w5NQNT6HN4Os5K7ZNClAGlM7Jul4Cxc7ft6vyH5jcaYJ8wWwZ1XOoLRrIo19Ti2N3GyDdhryvDb27-3VGAKtkbzLUIS3YZpsE4DydWniBcH2M4oTAywZmXubt7zJCReSWwyy571dyC8KCMrVic9W00S22w3UU-8hxR4zDW6o49bQCTJnlxRNGNaLHc"
                alt="Meditation"
                className="w-full h-full object-cover animate-mf-slow-zoom"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-mf-primary/30 to-transparent" />
            </div>
            {/* Spa icon overlay */}
            <div className="absolute -bottom-3 -right-3 w-14 h-14 rounded-2xl mf-gradient flex items-center justify-center shadow-lg animate-mf-float">
              <MaterialIcon icon="spa" filled className="text-white text-2xl" />
            </div>
          </div>

          {/* Spacer */}
          <div className="flex-1" />

          {/* CTA button */}
          <button
            onClick={handleContinue}
            className="w-full h-14 rounded-full mf-gradient text-white text-base font-semibold font-[var(--font-manrope)] tracking-wide shadow-lg shadow-mf-primary/20 hover:shadow-xl transition-all active:scale-[0.98] animate-mf-fade-up stagger-4"
          >
            Get Started
          </button>

          {/* Login link */}
          <button
            onClick={() => setView("home")}
            className="mt-4 text-sm text-mf-on-surface-variant dark:text-stone-400 text-center animate-mf-fade-up stagger-5 hover:text-mf-on-surface dark:hover:text-stone-200 transition-colors"
          >
            ALREADY HAVE AN ACCOUNT?{" "}
            <span className="font-semibold underline underline-offset-4">LOG IN</span>
          </button>

          {/* Progress dots */}
          <div className="mt-6">{renderProgressDots(0)}</div>
        </div>
      </div>
    );
  }

  // Step 1: Adaptive AI
  if (onboardingStep === 1) {
    return (
      <div className="min-h-screen bg-mf-surface dark:bg-[#0e0e0d] relative overflow-hidden flex flex-col">
        {/* Pulsing organic blob background */}
        <div
          className="fixed top-[30%] left-[50%] -translate-x-1/2 w-96 h-96 rounded-full animate-mf-pulse-organic pointer-events-none"
          style={{ background: "radial-gradient(circle, rgba(76,100,91,0.1) 0%, transparent 70%)" }}
        />

        <div className="relative z-10 flex flex-col h-full">
          {/* Header */}
          <header className="flex items-center justify-between px-5 pt-6 pb-4">
            <button
              onClick={() => setOnboardingStep(0)}
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-mf-surface-container-high dark:hover:bg-white/5 transition-colors"
            >
              <MaterialIcon icon="close" className="text-mf-on-surface-variant dark:text-stone-400 text-xl" />
            </button>
            <h1 className="text-lg font-bold text-mf-primary dark:text-emerald-400 font-[var(--font-manrope)]">
              MindFlow
            </h1>
            <div className="w-10" />
          </header>

          {/* Progress dots */}
          <div className="mb-4">{renderProgressDots(1)}</div>

          <div className="flex-1 px-6 pb-6 space-y-5 overflow-y-auto hide-scrollbar">
            {/* Glass card with data */}
            <div className="rounded-3xl p-4 space-y-3 animate-mf-scale-up bg-mf-surface-container-low dark:bg-stone-900/50">
              {/* Resting HR */}
              <div className="rounded-2xl p-4 bg-mf-surface-container-lowest dark:bg-stone-800/50">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <MaterialIcon icon="favorite" filled className="text-red-400 text-sm" />
                    <span className="text-xs font-medium text-mf-on-surface-variant dark:text-stone-400">
                      Resting HR
                    </span>
                  </div>
                  <span className="text-sm font-bold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                    64 BPM
                  </span>
                </div>
                <div className="flex items-end gap-1 h-10">
                  {[35, 50, 45, 60, 55, 70, 40, 65, 50, 75, 60, 55].map((h, i) => (
                    <div
                      key={i}
                      className={`flex-1 rounded-sm ${
                        i === 11 ? "bg-mf-primary dark:bg-emerald-400" : "bg-mf-primary/15 dark:bg-emerald-400/15"
                      }`}
                      style={{ height: `${h}%` }}
                    />
                  ))}
                </div>
              </div>

              {/* Calendar sync */}
              <div className="rounded-2xl p-4 bg-mf-tertiary-container/40 dark:bg-amber-900/20 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-mf-tertiary/10 dark:bg-amber-900/30 flex items-center justify-center shrink-0">
                  <MaterialIcon icon="event" className="text-mf-on-tertiary-container dark:text-amber-400 text-lg" />
                </div>
                <div>
                  <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">Next Meeting</p>
                  <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                    In 15 Minutes
                  </p>
                </div>
              </div>

              {/* AI suggestion */}
              <div className="rounded-2xl p-4 bg-mf-primary-container/50 dark:bg-emerald-900/20 flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-mf-primary/10 dark:bg-emerald-900/30 flex items-center justify-center shrink-0">
                  <MaterialIcon icon="auto_awesome" filled className="text-mf-on-primary-container dark:text-emerald-400 text-lg" />
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-mf-on-surface-variant dark:text-stone-500 uppercase tracking-wider mb-1">
                    AI Suggestion
                  </p>
                  <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                    Box Breath
                  </p>
                  <p className="text-xs text-mf-on-surface-variant dark:text-stone-400 mt-1">
                    Perfect before your upcoming meeting
                  </p>
                </div>
              </div>
            </div>

            {/* Heading */}
            <div className="animate-mf-fade-up stagger-2">
              <h2 className="text-3xl font-extrabold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)] leading-tight">
                Adapts to you,
                <br />
                in real-time.
              </h2>
              <p className="text-sm text-mf-on-surface-variant dark:text-stone-400 leading-relaxed mt-3 max-w-sm">
                MindFlow reads your biometrics, checks your schedule, and crafts the perfect
                meditation — adjusting breathwork, duration, and soundscapes to match how you
                feel right now.
              </p>
            </div>
          </div>

          {/* Bottom actions */}
          <div className="px-6 pb-8 pt-4 space-y-3">
            <button
              onClick={handleContinue}
              className="w-full h-14 rounded-full mf-gradient text-white text-base font-semibold font-[var(--font-manrope)] tracking-wide shadow-lg shadow-mf-primary/20 hover:shadow-xl transition-all active:scale-[0.98]"
            >
              Continue
            </button>
            <button
              onClick={handleSkip}
              className="w-full py-3 text-sm text-mf-on-surface-variant dark:text-stone-400 text-center hover:text-mf-on-surface dark:hover:text-stone-200 transition-colors"
            >
              Skip for now
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Step 2: Goals
  return (
    <div className="min-h-screen bg-mf-surface dark:bg-[#0e0e0d] relative overflow-hidden flex flex-col">
      <div className="relative z-10 flex flex-col h-full">
        {/* Header */}
        <header className="flex items-center justify-between px-5 pt-6 pb-4">
          <button
            onClick={() => setOnboardingStep(1)}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-mf-surface-container-high dark:hover:bg-white/5 transition-colors"
          >
            <MaterialIcon icon="close" className="text-mf-on-surface-variant dark:text-stone-400 text-xl" />
          </button>
          <h1 className="text-lg font-bold text-mf-primary dark:text-emerald-400 font-[var(--font-manrope)]">
            MindFlow
          </h1>
          <div className="w-10" />
        </header>

        {/* Progress dots */}
        <div className="mb-4">{renderProgressDots(2)}</div>

        <div className="flex-1 px-6 pb-6 space-y-5 overflow-y-auto hide-scrollbar">
          {/* Heading */}
          <div className="animate-mf-fade-up">
            <h2 className="text-[2.5rem] font-extrabold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)] leading-tight">
              What brings you
              <br />
              here today?
            </h2>
            <p className="text-sm text-mf-on-surface-variant dark:text-stone-400 mt-3">
              Select all that resonate with you
            </p>
          </div>

          {/* Goals grid - asymmetric */}
          <div className="grid grid-cols-2 gap-3 animate-mf-fade-up stagger-1">
            {/* Better Sleep */}
            <button
              onClick={() => toggleGoal("sleep")}
              className={`relative rounded-2xl p-5 text-left transition-all group ${
                selectedGoals.includes("sleep")
                  ? "bg-mf-primary-container dark:bg-emerald-900/30 ring-2 ring-mf-primary/30 dark:ring-emerald-500/30"
                  : "bg-mf-surface-container-low dark:bg-stone-900/50 hover:bg-mf-surface-container-high dark:hover:bg-stone-800/50"
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
                selectedGoals.includes("sleep") ? "bg-[#002019]/10 dark:bg-emerald-400/10" : "bg-mf-primary/10 dark:bg-emerald-900/20"
              }`}>
                <MaterialIcon icon="spa" filled className={`text-xl ${
                  selectedGoals.includes("sleep") ? "text-[#002019] dark:text-emerald-400" : "text-mf-primary dark:text-emerald-500"
                }`} />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                Better Sleep
              </p>
              <div className={`absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                selectedGoals.includes("sleep") ? "bg-mf-primary dark:bg-emerald-500 scale-100" : "scale-0"
              }`}>
                <MaterialIcon icon="check" filled className="text-white text-sm" />
              </div>
            </button>

            {/* Reduce Stress */}
            <button
              onClick={() => toggleGoal("stress")}
              className={`relative rounded-2xl p-5 text-left transition-all group mt-6 ${
                selectedGoals.includes("stress")
                  ? "bg-mf-secondary-container dark:bg-blue-900/30 ring-2 ring-mf-secondary/30 dark:ring-blue-500/30"
                  : "bg-mf-surface-container-low dark:bg-stone-900/50 hover:bg-mf-surface-container-high dark:hover:bg-stone-800/50"
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
                selectedGoals.includes("stress") ? "bg-[#35556b]/10 dark:bg-blue-400/10" : "bg-mf-secondary/10 dark:bg-blue-900/20"
              }`}>
                <MaterialIcon icon="psychology_alt" filled className={`text-xl ${
                  selectedGoals.includes("stress") ? "text-[#35556b] dark:text-blue-400" : "text-mf-secondary dark:text-blue-500"
                }`} />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                Reduce Stress
              </p>
              <div className={`absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                selectedGoals.includes("stress") ? "bg-mf-secondary dark:bg-blue-500 scale-100" : "scale-0"
              }`}>
                <MaterialIcon icon="check" filled className="text-white text-sm" />
              </div>
            </button>

            {/* Sharpen Focus */}
            <button
              onClick={() => toggleGoal("focus")}
              className={`relative rounded-2xl p-5 text-left transition-all group -mt-6 ${
                selectedGoals.includes("focus")
                  ? "bg-mf-tertiary-container dark:bg-amber-900/30 ring-2 ring-mf-tertiary/30 dark:ring-amber-500/30"
                  : "bg-mf-surface-container-low dark:bg-stone-900/50 hover:bg-mf-surface-container-high dark:hover:bg-stone-800/50"
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
                selectedGoals.includes("focus") ? "bg-[#62401c]/10 dark:bg-amber-400/10" : "bg-mf-tertiary/10 dark:bg-amber-900/20"
              }`}>
                <MaterialIcon icon="bolt" filled className={`text-xl ${
                  selectedGoals.includes("focus") ? "text-[#62401c] dark:text-amber-400" : "text-mf-tertiary dark:text-amber-500"
                }`} />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                Sharpen Focus
              </p>
              <div className={`absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                selectedGoals.includes("focus") ? "bg-mf-tertiary dark:bg-amber-500 scale-100" : "scale-0"
              }`}>
                <MaterialIcon icon="check" filled className="text-white text-sm" />
              </div>
            </button>

            {/* Deep Calm */}
            <button
              onClick={() => toggleGoal("calm")}
              className={`relative rounded-2xl p-5 text-left transition-all group ${
                selectedGoals.includes("calm")
                  ? "bg-mf-primary-container dark:bg-emerald-900/30 ring-2 ring-mf-primary/30 dark:ring-emerald-500/30"
                  : "bg-mf-surface-container-low dark:bg-stone-900/50 hover:bg-mf-surface-container-high dark:hover:bg-stone-800/50"
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
                selectedGoals.includes("calm") ? "bg-[#002019]/10 dark:bg-emerald-400/10" : "bg-mf-primary/10 dark:bg-emerald-900/20"
              }`}>
                <MaterialIcon icon="waves" filled className={`text-xl ${
                  selectedGoals.includes("calm") ? "text-[#002019] dark:text-emerald-400" : "text-mf-primary dark:text-emerald-500"
                }`} />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100 font-[var(--font-manrope)]">
                Deep Calm
              </p>
              <div className={`absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                selectedGoals.includes("calm") ? "bg-mf-primary dark:bg-emerald-500 scale-100" : "scale-0"
              }`}>
                <MaterialIcon icon="check" filled className="text-white text-sm" />
              </div>
            </button>
          </div>
        </div>

        {/* Bottom actions */}
        <div className="px-6 pb-8 pt-4 space-y-3">
          <button
            onClick={handleContinue}
            className="w-full h-14 rounded-full mf-gradient text-white text-base font-semibold font-[var(--font-manrope)] tracking-wide shadow-lg shadow-mf-primary/20 hover:shadow-xl transition-all active:scale-[0.98]"
          >
            Ready to begin
          </button>
          <p className="text-[10px] text-mf-on-surface-variant/50 dark:text-stone-600 text-center leading-relaxed">
            By continuing, you agree to MindFlow&apos;s{" "}
            <span className="underline">Terms of Service</span> and{" "}
            <span className="underline">Privacy Policy</span>
          </p>
        </div>
      </div>
    </div>
  );
}
