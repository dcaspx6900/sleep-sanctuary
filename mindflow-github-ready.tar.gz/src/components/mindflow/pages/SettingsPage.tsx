"use client";

import { useTheme } from "next-themes";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";
import { Switch } from "@/components/ui/switch";

const PROFILE_IMAGE_URL =
  "https://lh3.googleusercontent.com/aida-public/AB6AXuBp0zEZaM2TPJydM9HNbwWIP77PDYUDsA_saMncJ8xbBooy-1MioMRPzjE3Ts63nOUNc474P7iTgi-3_AaHGCbVDNYzIprLut5Q4C7tNbXiC1HnKx3G-d88vJqjzi02W9iLCUXvo4pUtDabM-R4lxH1V9ZUrM0XOYNztVB7gnM_2p1-uW446TZsfIDHUJ4-QnpYv5S08A0NRGbprERMvZXZVQonn9uIOh-VSZ7yQ4JZ-tfpfjcR_htu_WaFPQAvU06OpK5thajQZoQ";

export default function SettingsPage() {
  const { setView } = useAppStore();
  const { theme, setTheme } = useTheme();
  const isDark = theme === "dark";

  const navItems = [
    {
      icon: "devices",
      label: "Ecosystem",
      desc: "Connect devices & services",
      view: "ecosystem" as const,
    },
    {
      icon: "cloud_download",
      label: "Downloads",
      desc: "Offline sessions",
      view: "downloads" as const,
    },
    {
      icon: "workspace_premium",
      label: "Subscription",
      desc: "Manage membership",
      view: "subscription" as const,
    },
  ];

  return (
    <div className="px-5 pb-28">
      {/* Profile Card */}
      <section className="pt-3 pb-5">
        <div className="flex items-center gap-4 p-4 rounded-2xl bg-mf-surface-container-low dark:bg-stone-900/50">
          <div className="w-14 h-14 rounded-full overflow-hidden ring-2 ring-mf-primary-container/50 dark:ring-emerald-800/50 shrink-0">
            <img
              src={PROFILE_IMAGE_URL}
              alt="Profile"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-[var(--font-manrope)] font-bold text-lg text-mf-on-surface dark:text-stone-100 truncate">
              Alex
            </h2>
            <p className="text-sm text-mf-on-surface-variant dark:text-stone-400 mt-0.5">
              Meditation Journey — 42 days
            </p>
          </div>
          <button className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-mf-surface-container-high dark:hover:bg-white/5 transition-colors">
            <MaterialIcon icon="edit" className="text-mf-on-surface-variant dark:text-stone-400" size="sm" />
          </button>
        </div>
      </section>

      {/* Quick Settings */}
      <section className="pb-5">
        <h3 className="text-[10px] font-semibold text-mf-on-surface-variant dark:text-stone-500 mb-2 px-1 uppercase tracking-widest">
          Preferences
        </h3>
        <div className="rounded-2xl bg-mf-surface-container-low dark:bg-stone-900/50 divide-y divide-mf-outline-variant/20 dark:divide-white/5 overflow-hidden">
          {/* Dark Mode */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                <MaterialIcon icon="dark_mode" className="text-mf-primary dark:text-emerald-400" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">Dark Mode</p>
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">
                  {isDark ? "Active" : "Inactive"}
                </p>
              </div>
            </div>
            <Switch
              checked={isDark}
              onCheckedChange={(checked) => setTheme(checked ? "dark" : "light")}
              className="data-[state=checked]:bg-mf-primary dark:data-[state=checked]:bg-emerald-600"
            />
          </div>

          {/* Notifications */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                <MaterialIcon icon="notifications_active" className="text-mf-secondary dark:text-blue-400" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">Notifications</p>
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">Reminders & insights</p>
              </div>
            </div>
            <MaterialIcon icon="chevron_right" className="text-mf-on-surface-variant dark:text-stone-500" size="sm" />
          </div>

          {/* Sound */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                <MaterialIcon icon="vibration" className="text-mf-tertiary dark:text-amber-400" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">Sound & Haptics</p>
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">Audio settings</p>
              </div>
            </div>
            <MaterialIcon icon="chevron_right" className="text-mf-on-surface-variant dark:text-stone-500" size="sm" />
          </div>
        </div>
      </section>

      {/* Ecosystem Section */}
      <section className="pb-5">
        <h3 className="text-[10px] font-semibold text-mf-on-surface-variant dark:text-stone-500 mb-2 px-1 uppercase tracking-widest">
          Connect
        </h3>

        {/* Gemini Insight */}
        <div className="rounded-2xl bg-mf-secondary-container/30 dark:bg-blue-900/20 border-l-4 border-mf-secondary dark:border-blue-500 p-4 mb-3">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center shrink-0">
              <MaterialIcon icon="auto_awesome" filled className="text-white" />
            </div>
            <div>
              <p className="text-xs font-semibold text-mf-on-surface dark:text-stone-200">
                Gemini explains how your data is used.
              </p>
              <p className="text-[11px] text-mf-on-surface-variant dark:text-stone-400 mt-0.5">
                All processing happens on-device.
              </p>
            </div>
          </div>
        </div>

        {/* Wear OS highlighted card */}
        <div className="rounded-2xl p-4 mb-3 bg-mf-surface-container-low dark:bg-stone-900/50 relative overflow-hidden">
          <div className="absolute inset-0 rounded-2xl p-[1px] pointer-events-none" style={{ background: "linear-gradient(135deg, #4c645b, #436379, #7d5731)", opacity: 0.5 }}>
            <div className="w-full h-full rounded-2xl bg-mf-surface-container-low dark:bg-stone-900/50" />
          </div>
          <div className="relative flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-mf-primary-container dark:bg-emerald-900/30 flex items-center justify-center shrink-0">
              <MaterialIcon icon="watch" className="text-mf-on-primary-container dark:text-emerald-400" size="lg" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-mf-on-surface dark:text-stone-100">Connect Wear OS</p>
              <p className="text-xs text-mf-on-surface-variant dark:text-stone-400">Track stress & HRV</p>
            </div>
            <button className="shrink-0 px-3 py-1.5 rounded-full mf-gradient text-white text-[11px] font-semibold">
              Pair
            </button>
          </div>
        </div>

        {/* Ecosystem connections */}
        <div className="rounded-2xl bg-mf-surface-container-low dark:bg-stone-900/50 divide-y divide-mf-outline-variant/20 dark:divide-white/5 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                <MaterialIcon icon="calendar_month" className="text-mf-secondary dark:text-blue-400" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">Google Calendar</p>
                <p className="text-xs text-mf-primary dark:text-emerald-400 font-medium flex items-center gap-1">
                  <MaterialIcon icon="check_circle" filled size="sm" />Connected
                </p>
              </div>
            </div>
            <Switch defaultChecked className="data-[state=checked]:bg-mf-primary dark:data-[state=checked]:bg-emerald-600" />
          </div>
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                <MaterialIcon icon="favorite" className="text-mf-error dark:text-red-400" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">Health Connect</p>
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">Heart rate, sleep data</p>
              </div>
            </div>
            <MaterialIcon icon="open_in_new" className="text-mf-on-surface-variant dark:text-stone-500" size="sm" />
          </div>
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                <MaterialIcon icon="shield" className="text-mf-on-surface-variant dark:text-stone-400" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">Privacy</p>
                <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">Data & permissions</p>
              </div>
            </div>
            <MaterialIcon icon="chevron_right" className="text-mf-on-surface-variant dark:text-stone-500" size="sm" />
          </div>
        </div>
      </section>

      {/* Navigation Sub-pages */}
      <section>
        <h3 className="text-[10px] font-semibold text-mf-on-surface-variant dark:text-stone-500 mb-2 px-1 uppercase tracking-widest">
          Manage
        </h3>
        <div className="rounded-2xl bg-mf-surface-container-low dark:bg-stone-900/50 divide-y divide-mf-outline-variant/20 dark:divide-white/5 overflow-hidden">
          {navItems.map((item) => (
            <button
              key={item.view}
              onClick={() => setView(item.view)}
              className="flex items-center justify-between w-full px-4 py-3.5 hover:bg-mf-surface-container-high dark:hover:bg-stone-800/30 transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-mf-surface-container-high dark:bg-stone-800/50 flex items-center justify-center">
                  <MaterialIcon icon={item.icon} className="text-mf-on-surface-variant dark:text-stone-400" size="sm" />
                </div>
                <div>
                  <p className="text-sm font-medium text-mf-on-surface dark:text-stone-100">
                    {item.label}
                  </p>
                  <p className="text-xs text-mf-on-surface-variant dark:text-stone-500">
                    {item.desc}
                  </p>
                </div>
              </div>
              <MaterialIcon icon="chevron_right" className="text-mf-on-surface-variant dark:text-stone-500" size="sm" />
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
