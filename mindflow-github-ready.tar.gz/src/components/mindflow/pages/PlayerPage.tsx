"use client";

import { useState } from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

export default function PlayerPage() {
  const { goBack, setView, isPlaying, setPlaying } = useAppStore();
  const [progress, setProgress] = useState(70);

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ background: "#0e0e0d" }}>
      {/* Animated organic blobs */}
      <div
        className="absolute top-[15%] left-[10%] w-72 h-72 rounded-full animate-mf-breathe-slow pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(76,100,91,0.25) 0%, transparent 70%)" }}
      />
      <div
        className="absolute bottom-[20%] right-[5%] w-56 h-56 rounded-full animate-mf-breathe pointer-events-none"
        style={{
          background: "radial-gradient(circle, rgba(67,99,121,0.2) 0%, transparent 70%)",
          animationDelay: "3s",
        }}
      />
      <div
        className="absolute top-[50%] left-[50%] -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full animate-mf-pulse-organic pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(76,100,91,0.08) 0%, transparent 70%)" }}
      />

      <div className="relative z-10 min-h-screen flex flex-col px-5">
        {/* Header */}
        <header className="flex items-center justify-between pt-6 pb-4">
          <button
            onClick={goBack}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors"
          >
            <MaterialIcon icon="arrow_back" className="text-stone-400" />
          </button>
          <div className="text-center">
            <h1 className="text-base font-semibold text-stone-200 font-[var(--font-manrope)]">
              Deep Presence
            </h1>
          </div>
          <button className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors">
            <MaterialIcon icon="more_vert" className="text-stone-400" />
          </button>
        </header>

        {/* Central breathing circle */}
        <div className="flex-1 flex flex-col items-center justify-center -mt-10">
          <div className="relative w-64 h-64 mb-8">
            {/* Outer breathing ring */}
            <div
              className="absolute inset-0 rounded-full animate-mf-breathe"
              style={{
                background: "conic-gradient(from 0deg, rgba(76,100,91,0.3), rgba(67,99,121,0.2), rgba(125,87,49,0.15), rgba(76,100,91,0.3))",
                filter: "blur(1px)",
              }}
            />
            {/* Inner glow */}
            <div
              className="absolute inset-3 rounded-full animate-mf-breathe-slow"
              style={{
                background: "radial-gradient(circle, rgba(76,100,91,0.15) 0%, rgba(14,14,13,0.8) 70%)",
              }}
            />
            {/* Center content */}
            <div className="absolute inset-6 rounded-full flex flex-col items-center justify-center"
              style={{ background: "radial-gradient(circle, rgba(30,32,30,0.9) 0%, rgba(14,14,13,0.95) 100%)" }}
            >
              <span className="text-5xl font-[var(--font-manrope)] font-bold text-stone-100 tabular-nums mb-1">
                72
              </span>
              <span className="text-[10px] text-stone-500 uppercase tracking-widest">
                BPM
              </span>
            </div>
          </div>

          {/* Coherence panel */}
          <div className="glass-card dark rounded-2xl px-6 py-3 mb-6 border border-white/5">
            <div className="flex items-center gap-2">
              <MaterialIcon icon="activity" filled className="text-emerald-400" size="sm" />
              <span className="text-sm font-semibold text-stone-200 font-[var(--font-manrope)]">
                COHERENCE 88%
              </span>
            </div>
          </div>

          {/* Session info */}
          <div className="text-center mb-8">
            <p className="text-sm text-stone-400">Adaptive Breathwork</p>
            <p className="text-xs text-stone-500 mt-0.5">Evening Flow</p>
          </div>

          {/* Timer */}
          <div className="w-full max-w-xs mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-lg font-bold text-stone-200 tabular-nums font-[var(--font-manrope)]">
                14:02
              </span>
              <span className="text-sm text-stone-500 tabular-nums">20:00</span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-white/5 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-1000"
                style={{
                  width: `${progress}%`,
                  background: "linear-gradient(90deg, #4c645b, #cee9dd)",
                }}
              />
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-6 mb-8">
            <button className="w-12 h-12 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors">
              <MaterialIcon icon="replay_10" className="text-stone-400" size="lg" />
            </button>
            <button
              onClick={() => setPlaying(!isPlaying)}
              className="w-18 h-18 rounded-full flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
              style={{
                width: "4.5rem",
                height: "4.5rem",
                background: "linear-gradient(135deg, #4c645b 0%, #5a7d6e 100%)",
                boxShadow: "0 8px 32px rgba(76,100,91,0.4)",
              }}
            >
              <MaterialIcon
                icon={isPlaying ? "pause" : "play_arrow"}
                filled
                className="text-white text-3xl"
              />
            </button>
            <button className="w-12 h-12 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors">
              <MaterialIcon icon="forward_10" className="text-stone-400" size="lg" />
            </button>
          </div>

          {/* Bottom row */}
          <div className="flex items-center justify-between w-full max-w-xs pb-8">
            {/* Ambient selector */}
            <button className="flex items-center gap-2 px-3 py-2 rounded-full border border-white/10 hover:bg-white/5 transition-colors">
              <MaterialIcon icon="music_note" filled className="text-emerald-400" size="sm" />
              <span className="text-xs text-stone-300">Ambient Moss</span>
            </button>

            <div className="flex items-center gap-2">
              <button className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors">
                <MaterialIcon icon="favorite" className="text-stone-400" size="sm" />
              </button>
              <button className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors">
                <MaterialIcon icon="share" className="text-stone-400" size="sm" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
