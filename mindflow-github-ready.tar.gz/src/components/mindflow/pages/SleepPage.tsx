"use client";

import { useState } from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

export default function SleepPage() {
  const { setView } = useAppStore();
  const [isPaused, setIsPaused] = useState(false);
  const [intensity, setIntensity] = useState(42);

  const sleepTabs = [
    { id: "sleep", label: "Sleep", icon: "bedtime" },
    { id: "reflect", label: "Reflect", icon: "edit_note" },
    { id: "journey", label: "Journey", icon: "explore" },
    { id: "settings", label: "Settings", icon: "settings" },
  ];

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ background: "#0a0b0a" }}>
      {/* Ambient background circles */}
      <div
        className="fixed top-[-15%] left-[-15%] w-[400px] h-[400px] rounded-full animate-mf-breathe-slow pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(76,100,91,0.06) 0%, transparent 70%)" }}
      />
      <div
        className="fixed bottom-[-15%] right-[-15%] w-[350px] h-[350px] rounded-full animate-mf-breathe-slow pointer-events-none"
        style={{
          background: "radial-gradient(circle, rgba(67,99,121,0.05) 0%, transparent 70%)",
          animationDelay: "3s",
        }}
      />

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Minimalist Header - No top nav bar */}
        <header className="flex items-center justify-between px-5 pt-6 pb-2">
          <button
            onClick={() => setView("home")}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors"
          >
            <MaterialIcon icon="close" className="text-stone-400 text-xl" />
          </button>
          <h1 className="text-base font-semibold text-stone-300 font-[var(--font-manrope)] tracking-wide">
            Sleep Sanctuary
          </h1>
          <button className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors">
            <MaterialIcon icon="more_vert" className="text-stone-400 text-xl" />
          </button>
        </header>

        {/* Central celestial element */}
        <div className="flex-1 flex flex-col items-center justify-center px-5 -mt-4">
          {/* Ambient glow */}
          <div
            className="absolute w-80 h-80 rounded-full animate-mf-breathe pointer-events-none"
            style={{ background: "radial-gradient(circle, rgba(76,100,91,0.08) 0%, transparent 70%)" }}
          />

          {/* Main celestial circle */}
          <div className="relative w-64 h-64 mb-8">
            {/* Gradient border ring */}
            <div className="absolute inset-0 rounded-full p-[2px]" style={{ background: "linear-gradient(135deg, rgba(76,100,91,0.3), rgba(67,99,121,0.2), rgba(125,87,49,0.15))" }}>
              <div className="w-full h-full rounded-full" style={{ background: "#121312" }} />
            </div>
            {/* Inner circle */}
            <div
              className="absolute inset-3 rounded-full flex items-center justify-center"
              style={{ background: "radial-gradient(circle at 50% 50%, #1a1c1a 0%, #0e0f0e 100%)" }}
            >
              <div className="animate-mf-float">
                <MaterialIcon icon="bedtime" filled className="text-emerald-400/50 text-7xl" />
              </div>
            </div>
          </div>

          {/* Title */}
          <h2 className="text-2xl font-bold text-stone-200 font-[var(--font-manrope)] text-center mb-2">
            Midnight Whispers
          </h2>
          <p className="text-sm text-stone-500 text-center">
            Guided Sleep Meditation · 45m
          </p>
        </div>

        {/* Controls */}
        <div className="px-5 pb-8 space-y-5">
          {/* Timer + Ambient tiles */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl border border-white/5 p-4 flex flex-col items-center" style={{ background: "rgba(255,255,255,0.02)" }}>
              <MaterialIcon icon="schedule" className="text-stone-500 text-lg mb-1" />
              <p className="text-2xl font-bold text-stone-200 font-[var(--font-manrope)] tabular-nums">
                30:00
              </p>
              <p className="text-[10px] text-stone-600">remaining</p>
            </div>
            <div className="rounded-2xl border border-white/5 p-4 flex flex-col items-center" style={{ background: "rgba(255,255,255,0.02)" }}>
              <MaterialIcon icon="water_drop" filled className="text-blue-400/60 text-lg mb-1" />
              <p className="text-sm font-semibold text-stone-200 font-[var(--font-manrope)]">
                Rain in Kyoto
              </p>
              <p className="text-[10px] text-stone-600">ambient sound</p>
            </div>
          </div>

          {/* Pause button */}
          <div className="flex justify-center">
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="w-20 h-20 rounded-full border border-white/10 flex items-center justify-center transition-all hover:scale-105 active:scale-95"
              style={{
                background: "rgba(255,255,255,0.04)",
                boxShadow: "0 8px 32px rgba(0,0,0,0.3), 0 0 60px rgba(76,100,91,0.1)",
              }}
            >
              {isPaused ? (
                <MaterialIcon icon="play_arrow" filled className="text-stone-200 text-4xl ml-1" />
              ) : (
                <MaterialIcon icon="pause" filled className="text-stone-200 text-4xl" />
              )}
            </button>
          </div>

          {/* Intensity slider */}
          <div className="px-2">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-stone-500">Intensity</p>
              <p className="text-xs font-semibold text-stone-400 tabular-nums">{intensity}%</p>
            </div>
            <div className="relative w-full h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.05)" }}>
              <div
                className="absolute left-0 top-0 h-full rounded-full transition-all duration-300"
                style={{
                  width: `${intensity}%`,
                  background: "linear-gradient(90deg, rgba(76,100,91,0.5), rgba(200,230,255,0.5))",
                }}
              />
              <input
                type="range"
                min={0}
                max={100}
                value={intensity}
                onChange={(e) => setIntensity(Number(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <div
                className="absolute top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-stone-300 shadow-lg shadow-black/30 transition-all duration-300 pointer-events-none"
                style={{ left: `calc(${intensity}% - 8px)` }}
              />
            </div>
          </div>

          {/* Bottom pill nav */}
          <nav className="flex items-center justify-around py-2">
            {sleepTabs.map((tab) => (
              <button
                key={tab.id}
                className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-full transition-all ${
                  tab.id === "sleep"
                    ? "bg-emerald-950/50"
                    : "hover:bg-white/5"
                }`}
              >
                <MaterialIcon
                  icon={tab.icon}
                  filled={tab.id === "sleep"}
                  size="sm"
                  className={tab.id === "sleep" ? "text-emerald-400" : "text-stone-600"}
                />
                <span
                  className={`text-[9px] font-medium ${
                    tab.id === "sleep" ? "text-emerald-400" : "text-stone-600"
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            ))}
          </nav>
        </div>
      </div>
    </div>
  );
}
