"use client";

import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore, MAIN_TAB_VIEWS, HIDE_NAV_VIEWS } from "@/lib/store";

const tabs = [
  { viewId: "home" as const, icon: "home", label: "Home" },
  { viewId: "library" as const, icon: "auto_stories", label: "Library" },
  { viewId: "progress" as const, icon: "trending_up", label: "Progress" },
  { viewId: "settings" as const, icon: "settings", label: "Settings" },
];

export default function BottomNavBar() {
  const currentView = useAppStore((s) => s.currentView);
  const setView = useAppStore((s) => s.setView);

  if (HIDE_NAV_VIEWS.includes(currentView)) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50">
      <div className="mx-auto max-w-lg">
        <div className="mx-3 mb-2 rounded-[1.5rem] bg-mf-surface/70 dark:bg-[#0e0e0d]/70 backdrop-blur-2xl border border-mf-outline-variant/20 dark:border-white/5 shadow-lg shadow-black/5 dark:shadow-black/30">
          <div className="flex items-center justify-around px-2 pt-2 pb-3">
            {tabs.map((tab) => {
              const isActive = MAIN_TAB_VIEWS.includes(currentView)
                ? currentView === tab.viewId
                : false;
              return (
                <button
                  key={tab.viewId}
                  onClick={() => setView(tab.viewId)}
                  className={`flex flex-col items-center gap-0.5 transition-all duration-300 ease-out py-1 px-3 rounded-full ${
                    isActive
                      ? "bg-[#cee9dd] dark:bg-emerald-950/50"
                      : "hover:bg-mf-surface-container-high dark:hover:bg-white/5"
                  }`}
                >
                  <MaterialIcon
                    icon={tab.icon}
                    filled={isActive}
                    size={isActive ? "lg" : "md"}
                    className={
                      isActive
                        ? "text-[#002019] dark:text-emerald-300"
                        : "text-[#707973] dark:text-stone-500"
                    }
                  />
                  <span
                    className={`text-[10px] font-medium transition-colors duration-300 ${
                      isActive
                        ? "text-[#002019] dark:text-emerald-300"
                        : "text-[#707973] dark:text-stone-500"
                    }`}
                  >
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </div>
          {/* Safe area spacer */}
          <div className="h-2" />
        </div>
      </div>
    </nav>
  );
}
