"use client";

import React from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

interface TopBarProps {
  title?: string;
  showBack?: boolean;
  showNotification?: boolean;
  onBack?: () => void;
  rightAction?: React.ReactNode;
}

export default function TopBar({
  title,
  showBack = false,
  showNotification = false,
  onBack,
  rightAction,
}: TopBarProps) {
  const currentView = useAppStore((s) => s.currentView);

  const displayTitle = title ?? "MindFlow";
  const isHome = currentView === "home";

  return (
    <header className="sticky top-0 z-50 bg-mf-surface/80 backdrop-blur-md px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Left section */}
        <div className="flex items-center gap-3">
          {showBack ? (
            <button
              onClick={onBack}
              className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-mf-surface-container-high transition-colors"
              aria-label="Go back"
            >
              <MaterialIcon icon="keyboard_backspace" className="text-mf-on-surface" />
            </button>
          ) : (
            !isHome && <div className="w-10" />
          )}
          {isHome && (
            <div className="w-10 h-10 rounded-full mf-gradient flex items-center justify-center overflow-hidden">
              <MaterialIcon icon="self_improvement" className="text-white" size="lg" />
            </div>
          )}
          {title && (
            <h1 className="font-headline font-bold text-2xl text-mf-primary">
              {displayTitle}
            </h1>
          )}
        </div>

        {/* Right section */}
        <div className="flex items-center gap-2">
          {showNotification && (
            <button
              className="relative flex items-center justify-center w-10 h-10 rounded-full hover:bg-mf-surface-container-high transition-colors"
              aria-label="Notifications"
            >
              <MaterialIcon icon="notifications_none" className="text-mf-on-surface-variant" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-mf-error rounded-full" />
            </button>
          )}
          {rightAction}
          {isHome && (
            <div className="w-10 h-10 rounded-full bg-mf-primary-container/60 flex items-center justify-center overflow-hidden ml-1">
              <MaterialIcon icon="person" filled className="text-mf-on-primary-container" size="sm" />
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
