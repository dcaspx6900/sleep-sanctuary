"use client";

import React from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

export default function HomePage() {
  const { timeOfDay, setView } = useAppStore();

  const greetings: Record<string, string> = {
    morning: "Good Morning",
    afternoon: "Good Afternoon",
    evening: "Good Evening",
  };

  return (
    <div className="px-6 pb-24">
      {/* Hero */}
      <section className="pt-4 pb-6 animate-mf-fade-up">
        <p className="text-sm text-mf-on-surface-variant mb-1">{timeOfDay}</p>
        <h1 className="font-headline font-bold text-3xl text-mf-on-surface mb-2">
          {greetings[timeOfDay]}
        </h1>
        <p className="text-sm text-mf-on-surface-variant">
          Find your moment of calm today.
        </p>
      </section>

      {/* Mood Selection */}
      <section className="pb-6 animate-mf-fade-up stagger-1">
        <h2 className="font-headline font-semibold text-base text-mf-on-surface mb-3">
          How are you feeling?
        </h2>
        <div className="grid grid-cols-4 gap-3">
          {[
            { mood: "calm", icon: "spa", color: "bg-mf-primary-container", label: "Calm" },
            { mood: "anxious", icon: "air", color: "bg-mf-secondary-container", label: "Anxious" },
            { mood: "tired", icon: "bedtime", color: "bg-mf-tertiary-container", label: "Tired" },
            { mood: "focused", icon: "psychology", color: "bg-mf-surface-container-high", label: "Focused" },
          ].map((item) => (
            <button
              key={item.mood}
              onClick={() => setView("library")}
              className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-mf-surface-container-low hover:bg-mf-surface-container-high transition-colors"
            >
              <div className={`w-12 h-12 rounded-full ${item.color} flex items-center justify-center`}>
                <MaterialIcon icon={item.icon} className="text-mf-on-surface" size="sm" />
              </div>
              <span className="text-[11px] font-medium text-mf-on-surface-variant">
                {item.label}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Recommended Sessions */}
      <section className="pb-6 animate-mf-fade-up stagger-2">
        <h2 className="font-headline font-semibold text-base text-mf-on-surface mb-3">
          Recommended for You
        </h2>
        <div className="space-y-3">
          {[
            { title: "Morning Resilience", duration: "15 min", icon: "wb_sunny", color: "bg-mf-tertiary-container" },
            { title: "Ocean Breathwork", duration: "20 min", icon: "waves", color: "bg-mf-secondary-container" },
            { title: "Deep Focus Flow", duration: "25 min", icon: "bolt", color: "bg-mf-primary-container" },
          ].map((session, i) => (
            <button
              key={i}
              onClick={() => setView("player")}
              className="w-full flex items-center gap-4 p-4 rounded-2xl bg-mf-surface-container-low hover:bg-mf-surface-container-high transition-colors text-left"
            >
              <div className={`w-14 h-14 rounded-xl ${session.color} flex items-center justify-center shrink-0`}>
                <MaterialIcon icon={session.icon} className="text-mf-on-surface" size="lg" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-mf-on-surface">{session.title}</p>
                <p className="text-xs text-mf-on-surface-variant mt-0.5">{session.duration}</p>
              </div>
              <MaterialIcon icon="play_circle" className="text-mf-primary" size="lg" />
            </button>
          ))}
        </div>
      </section>

      {/* Quick Actions */}
      <section className="pb-6 animate-mf-fade-up stagger-3">
        <h2 className="font-headline font-semibold text-base text-mf-on-surface mb-3">
          Quick Actions
        </h2>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setView("sleep")}
            className="flex flex-col gap-2 p-4 rounded-2xl bg-gradient-to-br from-[#1a2f3a] to-[#2a4a5a] text-left"
          >
            <MaterialIcon icon="bedtime" filled className="text-[#a0c4ff]" size="lg" />
            <p className="text-sm font-semibold text-white">Sleep</p>
            <p className="text-[11px] text-white/60">Wind down tonight</p>
          </button>
          <button
            onClick={() => setView("reflection")}
            className="flex flex-col gap-2 p-4 rounded-2xl bg-gradient-to-br from-mf-primary to-[#5a7d6e] text-left"
          >
            <MaterialIcon icon="edit_note" filled className="text-mf-primary-fixed" size="lg" />
            <p className="text-sm font-semibold text-white">Reflect</p>
            <p className="text-[11px] text-white/60">Journal your thoughts</p>
          </button>
          <button
            onClick={() => setView("downloads")}
            className="flex flex-col gap-2 p-4 rounded-2xl bg-mf-surface-container-low text-left"
          >
            <MaterialIcon icon="cloud_download" filled className="text-mf-on-surface-variant" size="lg" />
            <p className="text-sm font-semibold text-mf-on-surface">Offline</p>
            <p className="text-[11px] text-mf-on-surface-variant">Download sessions</p>
          </button>
          <button
            onClick={() => setView("ecosystem")}
            className="flex flex-col gap-2 p-4 rounded-2xl bg-mf-surface-container-low text-left"
          >
            <MaterialIcon icon="devices" filled className="text-mf-on-surface-variant" size="lg" />
            <p className="text-sm font-semibold text-mf-on-surface">Ecosystem</p>
            <p className="text-[11px] text-mf-on-surface-variant">Connect devices</p>
          </button>
        </div>
      </section>
    </div>
  );
}
