"use client";

import React from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

export default function LibraryPage() {
  const { setView } = useAppStore();

  const categories = [
    { id: "all", label: "All", icon: "grid_view", active: true },
    { id: "meditation", label: "Meditation", icon: "self_improvement", active: false },
    { id: "breathing", label: "Breathing", icon: "air", active: false },
    { id: "sleep", label: "Sleep", icon: "bedtime", active: false },
    { id: "focus", label: "Focus", icon: "psychology", active: false },
  ];

  const sessions = [
    { title: "Morning Resilience", category: "Meditation", duration: "15 min", color: "bg-mf-tertiary-container", icon: "wb_sunny" },
    { title: "Ocean Breathwork", category: "Breathing", duration: "20 min", color: "bg-mf-secondary-container", icon: "waves" },
    { title: "Deep Focus Flow", category: "Focus", duration: "25 min", color: "bg-mf-primary-container", icon: "bolt" },
    { title: "Sunset Gratitude", category: "Meditation", duration: "12 min", color: "bg-mf-tertiary-container", icon: "wb_twilight" },
    { title: "Deep Sleep Forest", category: "Sleep", duration: "45 min", color: "bg-[#1a2f3a]/20", icon: "forest" },
    { title: "Anxiety Relief", category: "Breathing", duration: "10 min", color: "bg-mf-secondary-container", icon: "spa" },
  ];

  return (
    <div className="px-6 pb-24">
      {/* Header */}
      <section className="pt-2 pb-4 animate-mf-fade-up">
        <h1 className="font-headline font-bold text-2xl text-mf-on-surface mb-1">
          Session Library
        </h1>
        <p className="text-sm text-mf-on-surface-variant">
          Explore meditations crafted for every moment.
        </p>
      </section>

      {/* Category Chips */}
      <section className="pb-4 animate-mf-fade-up stagger-1">
        <div className="flex gap-2 overflow-x-auto hide-scrollbar -mx-6 px-6">
          {categories.map((cat) => (
            <button
              key={cat.id}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap transition-colors shrink-0 ${
                cat.active
                  ? "bg-mf-primary text-white"
                  : "bg-mf-surface-container-low text-mf-on-surface-variant hover:bg-mf-surface-container-high"
              }`}
            >
              <MaterialIcon icon={cat.icon} size="sm" />
              {cat.label}
            </button>
          ))}
        </div>
      </section>

      {/* Sessions Grid */}
      <section className="animate-mf-fade-up stagger-2">
        <div className="grid grid-cols-2 gap-3">
          {sessions.map((session, i) => (
            <button
              key={i}
              onClick={() => setView("player")}
              className="flex flex-col rounded-2xl bg-mf-surface-container-low overflow-hidden hover:bg-mf-surface-container-high transition-colors text-left"
            >
              <div className={`aspect-[4/3] ${session.color} flex items-center justify-center`}>
                <MaterialIcon icon={session.icon} className="text-mf-on-surface-variant/70" size="xl" />
              </div>
              <div className="p-3">
                <p className="text-sm font-semibold text-mf-on-surface truncate">{session.title}</p>
                <div className="flex items-center justify-between mt-1">
                  <p className="text-[11px] text-mf-on-surface-variant">{session.category}</p>
                  <p className="text-[11px] text-mf-on-surface-variant">{session.duration}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
