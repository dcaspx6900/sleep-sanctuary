"use client";

import React from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

export default function PlayerPage() {
  const { setView } = useAppStore();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a2f2a] to-[#0e0e0d] flex flex-col items-center justify-center px-6 text-white relative overflow-hidden">
      {/* Ambient blobs */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-mf-primary/20 organic-blob animate-mf-breathe-slow" />
      <div className="absolute bottom-1/4 right-1/4 w-48 h-48 rounded-full bg-mf-secondary/15 organic-blob animate-mf-breathe" />

      {/* Close button */}
      <button
        onClick={() => setView("home")}
        className="absolute top-8 right-6 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center z-10"
      >
        <MaterialIcon icon="close" className="text-white" />
      </button>

      {/* Album Art Placeholder */}
      <div className="w-56 h-56 rounded-3xl mf-gradient animate-mf-breathe flex items-center justify-center mb-8 shadow-2xl">
        <MaterialIcon icon="self_improvement" filled size="xl" className="text-white/90" />
      </div>

      {/* Session Info */}
      <div className="text-center mb-8 z-10">
        <h1 className="font-headline font-bold text-2xl mb-1">Morning Resilience</h1>
        <p className="text-white/60 text-sm">Guided Meditation · 15 min</p>
      </div>

      {/* Progress */}
      <div className="w-full max-w-xs mb-6 z-10">
        <div className="w-full h-1 rounded-full bg-white/10">
          <div className="h-full w-[35%] rounded-full bg-white/80" />
        </div>
        <div className="flex justify-between mt-2 text-xs text-white/40">
          <span>5:12</span>
          <span>15:00</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-8 z-10">
        <button className="w-12 h-12 rounded-full flex items-center justify-center">
          <MaterialIcon icon="skip_previous" className="text-white/70" size="lg" />
        </button>
        <button className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-lg">
          <MaterialIcon icon="pause" className="text-mf-primary" size="xl" />
        </button>
        <button className="w-12 h-12 rounded-full flex items-center justify-center">
          <MaterialIcon icon="skip_next" className="text-white/70" size="lg" />
        </button>
      </div>
    </div>
  );
}
