'use client';

import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import MaterialIcon from '@/components/MaterialIcon';

export default function OnboardingPage() {
  const { onboardingStep, setOnboardingStep, setView } = useAppStore();
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);

  const toggleGoal = (goal: string) => {
    setSelectedGoals((prev) =>
      prev.includes(goal) ? prev.filter((g) => g !== goal) : [...prev, goal]
    );
  };

  const handleContinue = () => {
    if (onboardingStep < 2) {
      setOnboardingStep(onboardingStep + 1);
    } else {
      setView('home');
    }
  };

  const handleSkip = () => {
    setOnboardingStep(2);
  };

  // Progress dots
  const renderProgressDots = (current: number) => (
    <div className="flex items-center justify-center gap-2">
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className={`w-2 h-2 rounded-full transition-all duration-500 ${
            i <= current
              ? 'bg-mf-primary scale-100'
              : 'bg-mf-outline-variant scale-75'
          }`}
        />
      ))}
    </div>
  );

  // Step 0: Welcome
  if (onboardingStep === 0) {
    return (
      <div className="min-h-screen bg-mf-surface relative overflow-hidden flex flex-col">
        {/* Background organic shapes */}
        <div className="absolute top-[-20%] right-[-15%] w-80 h-80 rounded-full bg-mf-primary-container/40 organic-blob animate-mf-breathe-slow pointer-events-none" />
        <div className="absolute bottom-[-10%] left-[-10%] w-72 h-72 rounded-full bg-mf-secondary-container/30 organic-blob animate-mf-breathe-slow pointer-events-none" style={{ animationDelay: '2s' }} />

        <div className="relative z-10 flex-1 flex flex-col px-6 pt-16 pb-10">
          {/* Brand */}
          <div className="animate-mf-fade-up mb-10">
            <h1 className="text-2xl font-bold text-mf-primary font-headline tracking-tight">
              MindFlow
            </h1>
          </div>

          {/* Hero heading */}
          <div className="animate-mf-fade-up stagger-1 mb-4">
            <h2 className="text-5xl md:text-6xl font-extrabold text-mf-on-surface font-headline leading-[1.1]">
              Welcome to
              <br />
              your sanctuary.
            </h2>
          </div>

          {/* Subtitle */}
          <p className="text-base text-mf-on-surface-variant leading-relaxed max-w-sm animate-mf-fade-up stagger-2 mb-8">
            Find clarity in the chaos. Discover personalized meditation that adapts to your
            rhythm, your mood, your life.
          </p>

          {/* Organic visual shape */}
          <div className="relative mx-auto mb-10 animate-mf-scale-up stagger-3">
            <div className="w-56 h-56 md:w-64 md:h-64 rounded-[60%_40%_30%_70%/_60%_30%_70%_40%] overflow-hidden relative shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600&h=600&fit=crop"
                alt="Meditation"
                className="w-full h-full object-cover animate-mf-slow-zoom"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-mf-primary/30 to-transparent" />
            </div>
            {/* Spa icon overlay */}
            <div className="absolute -bottom-3 -right-3 w-14 h-14 rounded-2xl mf-gradient flex items-center justify-center shadow-lg animate-mf-float">
              <MaterialIcon icon="spa" filled className="text-white text-2xl" />
            </div>
          </div>

          {/* Spacer */}
          <div className="flex-1" />

          {/* CTA button */}
          <button
            onClick={handleContinue}
            className="w-full h-16 rounded-full mf-gradient text-white text-base font-semibold font-headline tracking-wide shadow-lg shadow-mf-primary/20 hover:shadow-xl hover:shadow-mf-primary/30 transition-all active:scale-[0.98] animate-mf-fade-up stagger-4"
          >
            Get Started
          </button>

          {/* Login link */}
          <button
            onClick={() => setView('home')}
            className="mt-5 text-sm text-mf-on-surface-variant text-center animate-mf-fade-up stagger-5 hover:text-mf-on-surface transition-colors"
          >
            ALREADY HAVE AN ACCOUNT?{' '}
            <span className="font-semibold underline underline-offset-4">LOG IN</span>
          </button>

          {/* Progress dots */}
          <div className="mt-8">{renderProgressDots(0)}</div>
        </div>
      </div>
    );
  }

  // Step 1: Adaptive AI
  if (onboardingStep === 1) {
    return (
      <div className="min-h-screen bg-mf-surface relative overflow-hidden flex flex-col">
        <div className="relative z-10 flex flex-col h-full">
          {/* Header */}
          <header className="flex items-center justify-between px-5 pt-6 pb-4">
            <button
              onClick={() => setOnboardingStep(0)}
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-mf-surface-container-high transition-colors"
            >
              <MaterialIcon icon="close" className="text-mf-on-surface-variant text-xl" />
            </button>
            <h1 className="text-lg font-bold text-mf-primary font-headline">MindFlow</h1>
            <div className="w-10" />
          </header>

          {/* Progress dots */}
          <div className="mb-6">{renderProgressDots(1)}</div>

          <div className="flex-1 px-6 pb-10 space-y-6 overflow-y-auto hide-scrollbar">
            {/* Abstract generative visual card */}
            <div className="bg-mf-surface-container-low rounded-3xl p-5 space-y-4 animate-mf-scale-up">
              {/* Resting HR card */}
              <div className="bg-mf-surface-container-lowest rounded-2xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <MaterialIcon icon="favorite" filled className="text-red-400 text-sm" />
                    <span className="text-xs font-medium text-mf-on-surface-variant">
                      Resting HR
                    </span>
                  </div>
                  <span className="text-sm font-bold text-mf-on-surface font-headline">
                    64 BPM
                  </span>
                </div>
                {/* Mini bar chart */}
                <div className="flex items-end gap-1.5 h-10">
                  {[35, 50, 45, 60, 55, 70, 40, 65, 50, 75, 60, 55].map((h, i) => (
                    <div
                      key={i}
                      className={`flex-1 rounded-sm transition-all ${
                        i === 11 ? 'bg-mf-primary' : 'bg-mf-primary/15'
                      }`}
                      style={{ height: `${h}%` }}
                    />
                  ))}
                </div>
              </div>

              {/* Next meeting card */}
              <div className="bg-mf-tertiary-container/40 rounded-2xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-mf-tertiary/10 flex items-center justify-center flex-shrink-0">
                  <MaterialIcon icon="event" className="text-mf-on-tertiary-container text-lg" />
                </div>
                <div>
                  <p className="text-xs text-mf-on-surface-variant">Next Meeting</p>
                  <p className="text-sm font-semibold text-mf-on-surface font-headline">
                    In 15 Minutes
                  </p>
                </div>
              </div>

              {/* AI suggestion */}
              <div className="bg-mf-primary-container/50 rounded-2xl p-4 flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-mf-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <MaterialIcon icon="auto_awesome" filled className="text-mf-on-primary-container text-lg" />
                </div>
                <div>
                  <p className="text-[11px] font-medium text-mf-on-surface-variant uppercase tracking-wider mb-1">
                    AI Suggestion
                  </p>
                  <p className="text-sm font-semibold text-mf-on-surface font-headline">
                    Suggesting: Box Breath
                  </p>
                  <p className="text-xs text-mf-on-surface-variant mt-1">
                    Perfect before your upcoming meeting to center your focus
                  </p>
                </div>
              </div>
            </div>

            {/* Heading */}
            <div className="animate-mf-fade-up stagger-2">
              <h2 className="text-3xl md:text-4xl font-extrabold text-mf-on-surface font-headline leading-tight">
                Adapts to you,
                <br />
                in real-time.
              </h2>
              <p className="text-base text-mf-on-surface-variant leading-relaxed mt-3 max-w-sm">
                MindFlow reads your biometrics, checks your schedule, and crafts the perfect
                meditation — adjusting breathwork, duration, and soundscapes to match how you
                feel right now.
              </p>
            </div>
          </div>

          {/* Bottom actions */}
          <div className="px-6 pb-8 pt-4 space-y-3">
            <button
              onClick={handleContinue}
              className="w-full h-14 rounded-full mf-gradient text-white text-base font-semibold font-headline tracking-wide shadow-lg shadow-mf-primary/20 hover:shadow-xl transition-all active:scale-[0.98]"
            >
              Continue
            </button>
            <button
              onClick={handleSkip}
              className="w-full py-3 text-sm text-mf-on-surface-variant text-center hover:text-mf-on-surface transition-colors"
            >
              Skip for now
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Step 2: Goals
  return (
    <div className="min-h-screen bg-mf-surface relative overflow-hidden flex flex-col">
      <div className="relative z-10 flex flex-col h-full">
        {/* Header */}
        <header className="flex items-center justify-between px-5 pt-6 pb-4">
          <button
            onClick={() => setOnboardingStep(1)}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-mf-surface-container-high transition-colors"
          >
            <MaterialIcon icon="close" className="text-mf-on-surface-variant text-xl" />
          </button>
          <h1 className="text-lg font-bold text-mf-primary font-headline">MindFlow</h1>
          <div className="w-10" />
        </header>

        {/* Progress dots */}
        <div className="mb-6">{renderProgressDots(2)}</div>

        <div className="flex-1 px-6 pb-10 space-y-6 overflow-y-auto hide-scrollbar">
          {/* Heading */}
          <div className="animate-mf-fade-up">
            <h2
              className="text-[2.75rem] font-extrabold text-mf-on-surface font-headline leading-tight"
            >
              What brings you
              <br />
              here today?
            </h2>
            <p className="text-base text-mf-on-surface-variant mt-3">
              Select all that resonate with you
            </p>
          </div>

          {/* Goals 2x2 grid */}
          <div className="grid grid-cols-2 gap-3 animate-mf-fade-up stagger-1">
            {/* Better Sleep */}
            <button
              onClick={() => toggleGoal('sleep')}
              className={`relative rounded-2xl p-5 text-left transition-all group ${
                selectedGoals.includes('sleep')
                  ? 'bg-mf-primary-container ring-2 ring-mf-primary/30'
                  : 'bg-mf-surface-container-low hover:bg-mf-surface-container-high'
              }`}
            >
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
                  selectedGoals.includes('sleep')
                    ? 'bg-mf-on-primary-container/15'
                    : 'bg-mf-primary/10'
                }`}
              >
                <MaterialIcon
                  icon="spa"
                  filled
                  className={`text-xl ${
                    selectedGoals.includes('sleep')
                      ? 'text-mf-on-primary-container'
                      : 'text-mf-primary'
                  }`}
                />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface font-headline">
                Better Sleep
              </p>
              {/* Check icon on hover or selected */}
              <div
                className={`absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                  selectedGoals.includes('sleep')
                    ? 'bg-mf-primary scale-100 opacity-100'
                    : 'bg-mf-primary/0 group-hover:bg-mf-primary/10 scale-75 opacity-0 group-hover:opacity-100'
                }`}
              >
                <MaterialIcon icon="check_circle" filled className="text-white text-sm" />
              </div>
            </button>

            {/* Reduce Stress */}
            <button
              onClick={() => toggleGoal('stress')}
              className={`relative rounded-2xl p-5 text-left transition-all group mt-4 ${
                selectedGoals.includes('stress')
                  ? 'bg-mf-secondary-container ring-2 ring-mf-secondary/30'
                  : 'bg-mf-surface-container-low hover:bg-mf-surface-container-high'
              }`}
            >
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
                  selectedGoals.includes('stress')
                    ? 'bg-mf-on-secondary-container/15'
                    : 'bg-mf-secondary/10'
                }`}
              >
                <MaterialIcon
                  icon="psychology_alt"
                  filled
                  className={`text-xl ${
                    selectedGoals.includes('stress')
                      ? 'text-mf-on-secondary-container'
                      : 'text-mf-secondary'
                  }`}
                />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface font-headline">
                Reduce Stress
              </p>
              <div
                className={`absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                  selectedGoals.includes('stress')
                    ? 'bg-mf-secondary scale-100 opacity-100'
                    : 'bg-mf-secondary/0 group-hover:bg-mf-secondary/10 scale-75 opacity-0 group-hover:opacity-100'
                }`}
              >
                <MaterialIcon icon="check_circle" filled className="text-white text-sm" />
              </div>
            </button>

            {/* Sharpen Focus */}
            <button
              onClick={() => toggleGoal('focus')}
              className={`relative rounded-2xl p-5 text-left transition-all group -mt-4 ${
                selectedGoals.includes('focus')
                  ? 'bg-mf-tertiary-container ring-2 ring-mf-tertiary/30'
                  : 'bg-mf-surface-container-low hover:bg-mf-surface-container-high'
              }`}
            >
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
                  selectedGoals.includes('focus')
                    ? 'bg-mf-on-tertiary-container/15'
                    : 'bg-mf-tertiary/10'
                }`}
              >
                <MaterialIcon
                  icon="bolt"
                  filled
                  className={`text-xl ${
                    selectedGoals.includes('focus')
                      ? 'text-mf-on-tertiary-container'
                      : 'text-mf-tertiary'
                  }`}
                />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface font-headline">
                Sharpen Focus
              </p>
              <div
                className={`absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                  selectedGoals.includes('focus')
                    ? 'bg-mf-tertiary scale-100 opacity-100'
                    : 'bg-mf-tertiary/0 group-hover:bg-mf-tertiary/10 scale-75 opacity-0 group-hover:opacity-100'
                }`}
              >
                <MaterialIcon icon="check_circle" filled className="text-white text-sm" />
              </div>
            </button>

            {/* Deep Calm */}
            <button
              onClick={() => toggleGoal('calm')}
              className={`relative rounded-2xl p-5 text-left transition-all group ${
                selectedGoals.includes('calm')
                  ? 'bg-mf-primary-container ring-2 ring-mf-primary/30'
                  : 'bg-mf-surface-container-low hover:bg-mf-surface-container-high'
              }`}
            >
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
                  selectedGoals.includes('calm')
                    ? 'bg-mf-on-primary-container/15'
                    : 'bg-mf-primary/10'
                }`}
              >
                <MaterialIcon
                  icon="waves"
                  filled
                  className={`text-xl ${
                    selectedGoals.includes('calm')
                      ? 'text-mf-on-primary-container'
                      : 'text-mf-primary'
                  }`}
                />
              </div>
              <p className="text-sm font-semibold text-mf-on-surface font-headline">
                Deep Calm
              </p>
              <div
                className={`absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                  selectedGoals.includes('calm')
                    ? 'bg-mf-primary scale-100 opacity-100'
                    : 'bg-mf-primary/0 group-hover:bg-mf-primary/10 scale-75 opacity-0 group-hover:opacity-100'
                }`}
              >
                <MaterialIcon icon="check_circle" filled className="text-white text-sm" />
              </div>
            </button>
          </div>
        </div>

        {/* Bottom actions */}
        <div className="px-6 pb-8 pt-4 space-y-3">
          <button
            onClick={handleContinue}
            className="w-full h-14 rounded-full mf-gradient text-white text-base font-semibold font-headline tracking-wide shadow-lg shadow-mf-primary/20 hover:shadow-xl transition-all active:scale-[0.98]"
          >
            Ready to begin
          </button>
          <p className="text-[11px] text-mf-on-surface-variant/50 text-center leading-relaxed">
            By continuing, you agree to MindFlow&apos;s{' '}
            <span className="underline">Terms of Service</span> and{' '}
            <span className="underline">Privacy Policy</span>
          </p>
        </div>
      </div>
    </div>
  );
}
