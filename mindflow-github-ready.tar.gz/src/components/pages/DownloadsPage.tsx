"use client";

import React from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

interface DownloadItem {
  id: string;
  title: string;
  duration: string;
  size: string;
  status: "downloaded" | "downloading" | "queued";
  progress?: number;
  color: string;
}

const downloads: DownloadItem[] = [
  {
    id: "1",
    title: "Morning Resilience",
    duration: "15 mins",
    size: "42 MB",
    status: "downloaded",
    color: "bg-mf-primary-container",
  },
  {
    id: "2",
    title: "Ocean Breathwork",
    duration: "20 mins",
    size: "64 MB",
    status: "downloading",
    progress: 65,
    color: "bg-mf-secondary-container",
  },
  {
    id: "3",
    title: "Sunset Gratitude",
    duration: "12 mins",
    size: "28 MB",
    status: "queued",
    color: "bg-mf-tertiary-container",
  },
  {
    id: "4",
    title: "Deep Sleep Forest",
    duration: "45 mins",
    size: "88 MB",
    status: "downloaded",
    color: "bg-mf-primary-container",
  },
];

export default function DownloadsPage() {
  const { setView } = useAppStore();

  return (
    <div className="pb-24">
      {/* Storage Section */}
      <section className="px-6 pt-2 pb-6 animate-mf-fade-up">
        <h2 className="font-headline font-bold text-xl text-mf-on-surface mb-1">
          Offline Sanctuary
        </h2>
        <p className="text-sm text-mf-on-surface-variant mb-4">
          Your downloaded moments of peace, available anywhere.
        </p>

        {/* Storage Bar Card */}
        <div className="rounded-2xl bg-mf-surface-container-low p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm font-semibold text-mf-on-surface">
                Storage Used
              </p>
              <p className="text-xs text-mf-on-surface-variant mt-0.5">
                1.2 GB / 5 GB
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-mf-primary-container/60 text-xs font-semibold text-mf-on-primary-container">
              24 Sessions
            </span>
          </div>

          {/* Progress bar */}
          <div className="w-full h-2.5 rounded-full bg-mf-surface-container-highest overflow-hidden">
            <div
              className="h-full rounded-full mf-gradient animate-mf-grow-width"
              style={{ width: "24%" }}
            />
          </div>

          <p className="text-[11px] text-mf-on-surface-variant/60 italic mt-2 flex items-center gap-1">
            <MaterialIcon icon="auto_fix_high" size="sm" className="text-mf-on-surface-variant/40" />
            Optimization active — freeing up 120 MB...
          </p>
        </div>
      </section>

      {/* Downloads List */}
      <section className="px-6 pb-6 animate-mf-fade-up stagger-1">
        <h3 className="font-headline font-semibold text-sm text-mf-on-surface-variant mb-3 px-1 uppercase tracking-wider">
          Recently Saved
        </h3>
        <div className="space-y-3">
          {downloads.map((item) => (
            <div
              key={item.id}
              className="flex items-center gap-3 p-3 rounded-2xl bg-mf-surface-container-low"
            >
              {/* Thumbnail */}
              <div
                className={`w-14 h-14 rounded-xl ${item.color} flex items-center justify-center shrink-0`}
              >
                <MaterialIcon
                  icon={
                    item.status === "downloaded"
                      ? "cloud_done"
                      : item.status === "downloading"
                        ? "downloading"
                        : "schedule"
                  }
                  className="text-mf-on-surface-variant"
                  size="lg"
                />
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-mf-on-surface truncate">
                  {item.title}
                </p>
                <p className="text-xs text-mf-on-surface-variant mt-0.5">
                  {item.duration} · {item.size}
                </p>
                {item.status === "downloading" && (
                  <div className="mt-2 w-full h-1.5 rounded-full bg-mf-surface-container-highest overflow-hidden">
                    <div
                      className="h-full rounded-full mf-gradient transition-all duration-500"
                      style={{ width: `${item.progress}%` }}
                    />
                  </div>
                )}
                {item.status === "queued" && (
                  <p className="text-[11px] text-mf-on-surface-variant/60 mt-1 flex items-center gap-1">
                    <MaterialIcon icon="wifi" size="sm" className="text-mf-on-surface-variant/40" />
                    Waiting for Wi-Fi
                  </p>
                )}
              </div>

              {/* Status icon */}
              <div className="shrink-0">
                {item.status === "downloaded" && (
                  <MaterialIcon icon="check_circle" filled className="text-mf-primary" size="md" />
                )}
                {item.status === "downloading" && (
                  <div className="w-8 h-8 rounded-full flex items-center justify-center">
                    <MaterialIcon
                      icon="downloading"
                      className="text-mf-secondary animate-spin"
                      size="md"
                    />
                  </div>
                )}
                {item.status === "queued" && (
                  <MaterialIcon icon="schedule" className="text-mf-on-surface-variant/50" size="md" />
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-6 pb-8 animate-mf-fade-up stagger-2">
        <div className="rounded-2xl bg-gradient-to-br from-mf-primary-container/40 to-mf-secondary-container/30 p-5 border border-mf-primary/10">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 rounded-xl bg-mf-surface-container-low flex items-center justify-center shrink-0">
              <MaterialIcon icon="cleaning_services" className="text-mf-primary" size="lg" />
            </div>
            <div className="flex-1">
              <p className="font-headline font-bold text-base text-mf-on-surface">
                Space-Saving Mode
              </p>
              <p className="text-xs text-mf-on-surface-variant mt-1 leading-relaxed">
                Automatically remove listened sessions and keep your most-used meditations offline.
              </p>
              <button
                onClick={() => setView("settings")}
                className="mt-3 px-5 py-2 rounded-full bg-mf-primary text-white text-xs font-semibold hover:bg-mf-primary-dim transition-colors"
              >
                Enable Auto-Clean
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
