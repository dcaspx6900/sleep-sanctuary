"use client";

import React from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";
import { Switch } from "@/components/ui/switch";

interface SettingsPageProps {
  scrollToEcosystem?: boolean;
}

export default function SettingsPage({ scrollToEcosystem }: SettingsPageProps) {
  const { darkMode, toggleDarkMode, setView } = useAppStore();
  const ecosystemRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (scrollToEcosystem && ecosystemRef.current) {
      setTimeout(() => {
        ecosystemRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
  }, [scrollToEcosystem]);

  return (
    <div className="pb-24">
      {/* Profile Section */}
      <section className="px-6 pt-2 pb-4 animate-mf-fade-up">
        <div className="flex items-center gap-4 p-4 rounded-2xl bg-mf-surface-container-low">
          <div className="w-16 h-16 rounded-full mf-gradient flex items-center justify-center shrink-0">
            <MaterialIcon icon="person" filled size="xl" className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-headline font-bold text-lg text-mf-on-surface truncate">
              Alex
            </h2>
            <p className="text-sm text-mf-on-surface-variant mt-0.5">
              Meditation Journey — 42 days
            </p>
          </div>
          <button
            onClick={() => setView("profile")}
            className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-mf-surface-container-high transition-colors"
          >
            <MaterialIcon icon="edit" className="text-mf-on-surface-variant" size="sm" />
          </button>
        </div>
      </section>

      {/* Quick Settings */}
      <section className="px-6 pb-6 animate-mf-fade-up stagger-1">
        <h3 className="font-headline font-semibold text-sm text-mf-on-surface-variant mb-3 px-1 uppercase tracking-wider">
          Quick Settings
        </h3>
        <div className="rounded-2xl bg-mf-surface-container-low divide-y divide-mf-outline-variant/30 overflow-hidden">
          {/* Dark Mode */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high flex items-center justify-center">
                <MaterialIcon icon="dark_mode" className="text-mf-primary" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface">Dark Mode</p>
                <p className="text-xs text-mf-on-surface-variant">
                  {darkMode ? "Currently active" : "Currently inactive"}
                </p>
              </div>
            </div>
            <Switch
              checked={darkMode}
              onCheckedChange={toggleDarkMode}
              className="data-[state=checked]:bg-mf-primary"
            />
          </div>

          {/* Notifications */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high flex items-center justify-center">
                <MaterialIcon icon="notifications_active" className="text-mf-secondary" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface">Notifications</p>
                <p className="text-xs text-mf-on-surface-variant">Reminders &amp; insights</p>
              </div>
            </div>
            <MaterialIcon icon="chevron_right" className="text-mf-on-surface-variant" size="sm" />
          </div>

          {/* Sound & Haptics */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high flex items-center justify-center">
                <MaterialIcon icon="vibration" className="text-mf-tertiary" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface">Sound &amp; Haptics</p>
                <p className="text-xs text-mf-on-surface-variant">Audio &amp; vibration settings</p>
              </div>
            </div>
            <MaterialIcon icon="chevron_right" className="text-mf-on-surface-variant" size="sm" />
          </div>

          {/* Language */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high flex items-center justify-center">
                <MaterialIcon icon="translate" className="text-mf-primary" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface">Language</p>
                <p className="text-xs text-mf-on-surface-variant">English (US)</p>
              </div>
            </div>
            <MaterialIcon icon="chevron_right" className="text-mf-on-surface-variant" size="sm" />
          </div>
        </div>
      </section>

      {/* Ecosystem Section */}
      <section ref={ecosystemRef} className="px-6 pb-6 animate-mf-fade-up stagger-2">
        <h3 className="font-headline font-semibold text-sm text-mf-on-surface-variant mb-3 px-1 uppercase tracking-wider">
          Connect Your Devices
        </h3>

        {/* Gemini Insight Box */}
        <div className="rounded-2xl bg-mf-secondary-container/30 border-l-4 border-mf-secondary p-4 mb-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-mf-secondary-container/60 flex items-center justify-center shrink-0 mt-0.5">
              <MaterialIcon icon="auto_awesome" className="text-mf-on-secondary-container" size="sm" />
            </div>
            <div>
              <p className="text-sm font-semibold text-mf-on-surface mb-1">
                Gemini Insight
              </p>
              <p className="text-xs text-mf-on-surface-variant leading-relaxed">
                Your meditation patterns adapt using on-device AI. All personal data stays 
                private — insights are processed locally and never leave your device.
              </p>
            </div>
          </div>
        </div>

        {/* Wear OS Card */}
        <div className="rounded-2xl p-4 mb-4 bg-mf-surface-container-low relative overflow-hidden">
          {/* Gradient border effect */}
          <div className="absolute inset-0 rounded-2xl p-[2px] bg-gradient-to-br from-mf-primary via-mf-secondary to-mf-tertiary opacity-60 pointer-events-none">
            <div className="w-full h-full rounded-2xl bg-mf-surface-container-low" />
          </div>
          <div className="relative flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-mf-primary-container flex items-center justify-center shrink-0">
              <MaterialIcon icon="watch" className="text-mf-on-primary-container" size="lg" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-mf-on-surface">Connect Wear OS</p>
              <p className="text-xs text-mf-on-surface-variant mt-0.5">
                Track stress &amp; HRV during sessions
              </p>
            </div>
            <button className="shrink-0 px-4 py-2 rounded-full bg-mf-primary text-white text-xs font-semibold hover:bg-mf-primary-dim transition-colors">
              Pair Device
            </button>
          </div>
        </div>

        {/* Ecosystem List */}
        <div className="rounded-2xl bg-mf-surface-container-low divide-y divide-mf-outline-variant/30 overflow-hidden">
          {/* Google Calendar Sync */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high flex items-center justify-center">
                <MaterialIcon icon="calendar_month" className="text-mf-secondary" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface">Google Calendar Sync</p>
                <p className="text-xs text-mf-primary font-medium flex items-center gap-1">
                  <MaterialIcon icon="check_circle" filled size="sm" className="text-mf-primary" />
                  Connected
                </p>
              </div>
            </div>
            <Switch defaultChecked className="data-[state=checked]:bg-mf-primary" />
          </div>

          {/* Health Connect */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high flex items-center justify-center">
                <MaterialIcon icon="favorite" className="text-mf-error" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface">Health Connect Permissions</p>
                <p className="text-xs text-mf-on-surface-variant">Heart rate, sleep data</p>
              </div>
            </div>
            <MaterialIcon icon="open_in_new" className="text-mf-on-surface-variant" size="sm" />
          </div>

          {/* Privacy & Security */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-mf-surface-container-high flex items-center justify-center">
                <MaterialIcon icon="shield" className="text-mf-on-surface-variant" size="sm" />
              </div>
              <div>
                <p className="text-sm font-medium text-mf-on-surface">Privacy &amp; Security</p>
                <p className="text-xs text-mf-on-surface-variant">Data &amp; permissions</p>
              </div>
            </div>
            <MaterialIcon icon="chevron_right" className="text-mf-on-surface-variant" size="sm" />
          </div>
        </div>
      </section>

      {/* Footer */}
      <section className="px-6 pb-8 animate-mf-fade-up stagger-3">
        <div className="flex items-center justify-center gap-6 py-4 border-t border-mf-outline-variant/20">
          <MaterialIcon icon="watch" className="text-mf-on-surface-variant/50" size="sm" />
          <MaterialIcon icon="devices" className="text-mf-on-surface-variant/50" size="sm" />
          <MaterialIcon icon="bluetooth" className="text-mf-on-surface-variant/50" size="sm" />
          <MaterialIcon icon="health_and_safety" className="text-mf-on-surface-variant/50" size="sm" />
        </div>
        <button className="w-full text-center text-xs text-mf-on-surface-variant/60 hover:text-mf-primary transition-colors py-2">
          Integration Setup Guide →
        </button>
      </section>
    </div>
  );
}
