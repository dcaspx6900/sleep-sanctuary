"use client";

import React from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore } from "@/lib/store";

export default function ProgressPage() {
  const { setView } = useAppStore();

  const stats = [
    { label: "Total Sessions", value: "42", icon: "self_improvement", color: "text-mf-primary" },
    { label: "Minutes", value: "6.5h", icon: "schedule", color: "text-mf-secondary" },
    { label: "Streak", value: "12", icon: "local_fire_department", color: "text-mf-tertiary" },
    { label: "Avg Focus", value: "87%", icon: "psychology", color: "text-mf-primary" },
  ];

  const weekDays = [
    { day: "Mon", minutes: 15, completed: true },
    { day: "Tue", minutes: 20, completed: true },
    { day: "Wed", minutes: 0, completed: false },
    { day: "Thu", minutes: 10, completed: true },
    { day: "Fri", minutes: 25, completed: true },
    { day: "Sat", minutes: 0, completed: false },
    { day: "Sun", minutes: 15, completed: true },
  ];

  const maxMinutes = Math.max(...weekDays.map((d) => d.minutes));

  return (
    <div className="px-6 pb-24">
      {/* Header */}
      <section className="pt-2 pb-4 animate-mf-fade-up">
        <h1 className="font-headline font-bold text-2xl text-mf-on-surface mb-1">
          Your Journey
        </h1>
        <p className="text-sm text-mf-on-surface-variant">
          Track your mindfulness progress over time.
        </p>
      </section>

      {/* Stats Grid */}
      <section className="pb-6 animate-mf-fade-up stagger-1">
        <div className="grid grid-cols-2 gap-3">
          {stats.map((stat, i) => (
            <div key={i} className="p-4 rounded-2xl bg-mf-surface-container-low">
              <MaterialIcon icon={stat.icon} className={stat.color} size="md" />
              <p className="font-headline font-bold text-2xl text-mf-on-surface mt-2">
                {stat.value}
              </p>
              <p className="text-xs text-mf-on-surface-variant">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Weekly Chart */}
      <section className="pb-6 animate-mf-fade-up stagger-2">
        <h2 className="font-headline font-semibold text-base text-mf-on-surface mb-3">
          This Week
        </h2>
        <div className="p-4 rounded-2xl bg-mf-surface-container-low">
          <div className="flex items-end justify-between gap-2 h-32">
            {weekDays.map((day) => (
              <div key={day.day} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full flex flex-col items-center justify-end h-24">
                  <div
                    className={`w-full rounded-full transition-all duration-500 ${
                      day.completed ? "mf-gradient" : "bg-mf-surface-container-highest"
                    }`}
                    style={{
                      height: day.minutes > 0 ? `${(day.minutes / maxMinutes) * 100}%` : "4px",
                      minHeight: "4px",
                    }}
                  />
                </div>
                <span
                  className={`text-[10px] font-medium ${
                    day.completed ? "text-mf-on-surface" : "text-mf-on-surface-variant/50"
                  }`}
                >
                  {day.day}
                </span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-mf-outline-variant/20">
            <span className="text-xs text-mf-on-surface-variant">
              5 of 7 days active
            </span>
            <button
              onClick={() => setView("reflection")}
              className="text-xs text-mf-primary font-semibold"
            >
              View Details →
            </button>
          </div>
        </div>
      </section>

      {/* Milestones */}
      <section className="pb-6 animate-mf-fade-up stagger-3">
        <h2 className="font-headline font-semibold text-base text-mf-on-surface mb-3">
          Milestones
        </h2>
        <div className="space-y-3">
          {[
            { title: "Week Warrior", desc: "7-day meditation streak", icon: "military_tech", achieved: true },
            { title: "Zen Master", desc: "Complete 50 sessions", icon: "stars", achieved: false, progress: "84%" },
            { title: "Night Owl", desc: "10 sleep sessions", icon: "nights_stay", achieved: true },
          ].map((milestone, i) => (
            <div
              key={i}
              className="flex items-center gap-3 p-3 rounded-2xl bg-mf-surface-container-low"
            >
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 ${
                  milestone.achieved ? "bg-mf-tertiary-container" : "bg-mf-surface-container-high"
                }`}
              >
                <MaterialIcon
                  icon={milestone.icon}
                  filled={milestone.achieved}
                  className={milestone.achieved ? "text-mf-on-tertiary-container" : "text-mf-on-surface-variant/40"}
                  size="sm"
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-mf-on-surface">{milestone.title}</p>
                <p className="text-xs text-mf-on-surface-variant">{milestone.desc}</p>
              </div>
              {milestone.achieved ? (
                <MaterialIcon icon="check_circle" filled className="text-mf-primary" size="md" />
              ) : (
                <span className="text-xs font-semibold text-mf-primary">{milestone.progress}</span>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
