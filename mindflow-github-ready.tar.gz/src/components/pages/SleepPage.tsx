'use client';

import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import MaterialIcon from '@/components/MaterialIcon';

export default function SleepPage() {
  const { setView } = useAppStore();
  const [isPaused, setIsPaused] = useState(false);
  const [intensity, setIntensity] = useState(42);

  return (
    <div className="dark min-h-screen relative overflow-hidden" style={{ background: '#0a0b0a' }}>
      {/* Background ambient circles */}
      <div className="fixed top-[-10%] left-[-15%] w-[400px] h-[400px] rounded-full bg-mf-primary/5 blur-[120px] animate-mf-breathe-slow pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-15%] w-[350px] h-[350px] rounded-full bg-mf-secondary/5 blur-[120px] animate-mf-breathe-slow pointer-events-none" style={{ animationDelay: '3s' }} />

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Minimalist Header */}
        <header className="flex items-center justify-between px-5 pt-6 pb-2">
          <button
            onClick={() => setView('home')}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors"
          >
            <MaterialIcon icon="close" className="text-mf-on-surface-variant/80 text-xl" />
          </button>
          <h1 className="text-base font-semibold text-mf-on-surface-variant/80 font-headline tracking-wide">
            Sleep Sanctuary
          </h1>
          <button className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors">
            <MaterialIcon icon="more_vert" className="text-mf-on-surface-variant/80 text-xl" />
          </button>
        </header>

        {/* Central Celestial Element */}
        <div className="flex-1 flex flex-col items-center justify-center px-5 -mt-4">
          {/* Ambient glow circles */}
          <div className="absolute w-80 h-80 md:w-96 md:h-96 rounded-full bg-mf-primary/8 blur-[80px] animate-mf-breathe pointer-events-none" />
          <div className="absolute w-64 h-64 md:w-72 md:h-72 rounded-full bg-mf-secondary/5 blur-[60px] animate-mf-breathe pointer-events-none" style={{ animationDelay: '2s' }} />

          {/* Main celestial circle */}
          <div className="relative w-64 h-64 md:w-80 md:h-80 mb-8">
            {/* Gradient border ring */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-mf-primary/30 via-mf-secondary/20 to-mf-tertiary/20 p-[2px]">
              <div className="w-full h-full rounded-full" style={{ background: '#121312' }} />
            </div>
            {/* Inner circle */}
            <div className="absolute inset-3 rounded-full flex items-center justify-center" style={{ background: 'radial-gradient(circle at 50% 50%, #1a1c1a 0%, #0e0f0e 100%)' }}>
              <div className="animate-mf-float">
                <MaterialIcon icon="bedtime" filled className="text-mf-primary/60 text-7xl md:text-8xl" />
              </div>
            </div>
          </div>

          {/* Title */}
          <h2 className="text-2xl md:text-3xl font-bold text-mf-on-surface font-headline text-center mb-2 animate-mf-fade-up">
            Midnight Whispers
          </h2>
          <p className="text-sm text-mf-on-surface-variant/60 text-center animate-mf-fade-up stagger-1">
            Guided Sleep Meditation · 45m
          </p>
        </div>

        {/* Contextual Controls */}
        <div className="px-5 pb-10 space-y-5">
          {/* Timer + Ambient tiles */}
          <div className="grid grid-cols-2 gap-3 animate-mf-fade-up stagger-2">
            {/* Timer tile */}
            <div className="rounded-2xl border border-white/5 backdrop-blur-xl p-4 flex flex-col items-center gap-1" style={{ background: 'rgba(255,255,255,0.03)' }}>
              <MaterialIcon icon="schedule" className="text-mf-on-surface-variant/50 text-lg mb-1" />
              <p className="text-2xl font-bold text-mf-on-surface font-headline tabular-nums">
                30:00
              </p>
              <p className="text-[11px] text-mf-on-surface-variant/40">remaining</p>
            </div>

            {/* Ambient tile */}
            <div className="rounded-2xl border border-white/5 backdrop-blur-xl p-4 flex flex-col items-center gap-1" style={{ background: 'rgba(255,255,255,0.03)' }}>
              <MaterialIcon icon="water_drop" filled className="text-mf-secondary/70 text-lg mb-1" />
              <p className="text-sm font-semibold text-mf-on-surface font-headline">
                Rain in Kyoto
              </p>
              <p className="text-[11px] text-mf-on-surface-variant/40">ambient sound</p>
            </div>
          </div>

          {/* Pause button */}
          <div className="flex justify-center animate-mf-fade-up stagger-3">
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="w-20 h-20 rounded-full border border-white/10 backdrop-blur-xl shadow-lg shadow-black/20 flex items-center justify-center transition-all hover:scale-105 active:scale-95"
              style={{
                background: 'rgba(255,255,255,0.06)',
                boxShadow: '0 8px 32px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.05)',
              }}
            >
              {isPaused ? (
                <MaterialIcon icon="play_arrow" filled className="text-mf-on-surface text-4xl ml-1" />
              ) : (
                <MaterialIcon icon="pause" filled className="text-mf-on-surface text-4xl" />
              )}
            </button>
          </div>

          {/* Intensity slider */}
          <div className="animate-mf-fade-up stagger-4 px-2">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-mf-on-surface-variant/50">Intensity</p>
              <p className="text-xs font-semibold text-mf-on-surface-variant/70 tabular-nums">{intensity}%</p>
            </div>
            <div className="relative w-full h-1.5 rounded-full bg-white/5">
              <div
                className="absolute left-0 top-0 h-full rounded-full transition-all duration-300"
                style={{
                  width: `${intensity}%`,
                  background: 'linear-gradient(90deg, rgba(76,100,91,0.5), rgba(200,230,255,0.5))',
                }}
              />
              <input
                type="range"
                min={0}
                max={100}
                value={intensity}
                onChange={(e) => setIntensity(Number(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              {/* Thumb indicator */}
              <div
                className="absolute top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-mf-on-surface shadow-lg shadow-black/30 transition-all duration-300 pointer-events-none"
                style={{ left: `calc(${intensity}% - 8px)` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
