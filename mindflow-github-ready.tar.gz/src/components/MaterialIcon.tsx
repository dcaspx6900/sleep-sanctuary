"use client";

import React from "react";

interface MaterialIconProps {
  icon: string;
  filled?: boolean;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  style?: React.CSSProperties;
  onClick?: () => void;
}

const sizeClasses: Record<string, string> = {
  sm: "text-[20px]",
  md: "text-[24px]",
  lg: "text-[28px]",
  xl: "text-[32px]",
};

export default function MaterialIcon({
  icon,
  filled = false,
  size = "md",
  className = "",
  style,
  onClick,
}: MaterialIconProps) {
  return (
    <span
      className={`material-symbols-outlined select-none inline-flex items-center justify-center ${
        sizeClasses[size]
      } ${filled ? "filled" : ""} ${className}`}
      style={{
        fontVariationSettings: filled
          ? "'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24"
          : "'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24",
        ...style,
      }}
      onClick={onClick}
    >
      {icon}
    </span>
  );
}
