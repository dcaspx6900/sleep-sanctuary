"use client";

import React from "react";
import MaterialIcon from "@/components/MaterialIcon";
import { useAppStore, type ViewId } from "@/lib/store";

interface NavTab {
  viewId: ViewId;
  icon: string;
  label: string;
}

const tabs: NavTab[] = [
  { viewId: "home", icon: "home_max", label: "Home" },
  { viewId: "library", icon: "subscriptions", label: "Library" },
  { viewId: "progress", icon: "leaderboard", label: "Progress" },
  { viewId: "settings", icon: "settings", label: "Settings" },
];

export default function BottomNav() {
  const currentView = useAppStore((s) => s.currentView);
  const setView = useAppStore((s) => s.setView);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50">
      <div className="mx-auto max-w-lg rounded-t-[2rem] bg-mf-surface/60 backdrop-blur-3xl border-t border-mf-outline-variant/30">
        <div className="flex items-center justify-around px-4 pt-2 pb-3">
          {tabs.map((tab) => {
            const isActive = currentView === tab.viewId;
            return (
              <button
                key={tab.viewId}
                onClick={() => setView(tab.viewId)}
                className={`flex flex-col items-center gap-0.5 transition-all duration-300 ease-out ${
                  isActive
                    ? "scale-105"
                    : "hover:scale-110 text-[#707973] dark:text-[#8a938c]"
                }`}
              >
                <div
                  className={`flex items-center justify-center rounded-full transition-all duration-300 ease-out ${
                    isActive
                      ? "bg-mf-primary-container px-5 py-1"
                      : "px-4 py-1"
                  }`}
                >
                  <MaterialIcon
                    icon={tab.icon}
                    filled={isActive}
                    size={isActive ? "lg" : "md"}
                    className={
                      isActive
                        ? "text-[#002019]"
                        : "text-[#707973] dark:text-[#8a938c]"
                    }
                  />
                </div>
                <span
                  className={`text-[10px] font-medium transition-colors duration-300 ${
                    isActive
                      ? "text-[#002019]"
                      : "text-[#707973] dark:text-[#8a938c]"
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
        {/* Safe area spacer for mobile */}
        <div className="h-safe-area-inset-bottom" />
      </div>
    </nav>
  );
}
