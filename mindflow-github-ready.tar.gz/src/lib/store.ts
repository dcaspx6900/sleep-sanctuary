import { create } from "zustand";

export type ViewId =
  | "home"
  | "library"
  | "progress"
  | "settings"
  | "player"
  | "reflection"
  | "sleep"
  | "onboarding"
  | "downloads"
  | "ecosystem"
  | "subscription";

interface AppState {
  currentView: ViewId;
  selectedMood: string | null;
  onboardingStep: number;
  isPlaying: boolean;
  timeOfDay: "morning" | "afternoon" | "evening";
  navigationHistory: ViewId[];

  setView: (view: ViewId) => void;
  goBack: () => void;
  setMood: (mood: string | null) => void;
  setOnboardingStep: (step: number) => void;
  setPlaying: (playing: boolean) => void;
}

export const useAppStore = create<AppState>((set) => {
  const hour = new Date().getHours();
  const timeOfDay =
    hour < 12 ? "morning" : hour < 18 ? "afternoon" : "evening";

  return {
    currentView: "onboarding",
    selectedMood: null,
    onboardingStep: 0,
    isPlaying: true,
    timeOfDay,
    navigationHistory: [],

    setView: (view) =>
      set((state) => ({
        currentView: view,
        navigationHistory: [...state.navigationHistory, state.currentView],
      })),

    goBack: () =>
      set((state) => {
        const history = [...state.navigationHistory];
        const prevView = history.pop();
        return {
          currentView: prevView ?? "home",
          navigationHistory: history,
        };
      }),

    setMood: (mood) => set({ selectedMood: mood }),
    setOnboardingStep: (step) => set({ onboardingStep: step }),
    setPlaying: (playing) => set({ isPlaying: playing }),
  };
});

/** Pages that hide the bottom nav bar */
export const HIDE_NAV_VIEWS: ViewId[] = [
  "onboarding",
  "player",
  "sleep",
];

/** Pages that force dark mode regardless of theme */
export const FORCE_DARK_VIEWS: ViewId[] = ["player", "sleep"];

/** Pages that hide the top app bar */
export const HIDE_TOPBAR_VIEWS: ViewId[] = ["onboarding", "sleep"];

/** Main tab views for bottom nav */
export const MAIN_TAB_VIEWS: ViewId[] = ["home", "library", "progress", "settings"];
