"use client";

import AppShell from "@/components/mindflow/AppShell";

export default function Home() {
  return <AppShell />;
}
